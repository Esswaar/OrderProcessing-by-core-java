import React, { Suspense } from "react";
import { Redirect, Route, Switch, withRouter } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import * as actions from "../store/actions/auth.action";
import SuspenseSpinner from "../components/UI/Spinner/SuspenseSpinner";
import Layout from "../hoc/Layout/Layout";
import "bootstrap/dist/css/bootstrap.min.css";

const Auth = React.lazy(() => import("../container/Auth/Auth"));
const Applications = React.lazy(() =>
  import("../container/Applications/Applications")
);
const CaseTypes = React.lazy(() => import("../container/CaseTypes/CaseTypes"));
const CaseTypeDetail = React.lazy(() =>
  import("../container/CaseTypeDetail/CaseTypeDetail")
);

const App = (props) => {
  const isAuthenticated = useSelector((state) =>
    state.auth.token ? true : false
  );

  const authRoute = useSelector((state) => state.auth.route);
  const dispatch = useDispatch();

  let suspenseSpinner = <SuspenseSpinner />;

  let routeTo = (
    <Switch>
      <Route path="/auth" component={Auth} />
      <Redirect from="/" to="/auth" />
    </Switch>
  );

  if (isAuthenticated) {
    suspenseSpinner = (
      <Layout>
        <SuspenseSpinner isInLayout={true} />
      </Layout>
    );
    routeTo = (
      <Layout>
        <Switch>
          <Route
            path="/apps/:appID/casetypes/:caseTypeID"
            component={CaseTypeDetail}
          />
          <Route path="/apps/:appID/casetypes" component={CaseTypes} />
          <Route path="/apps" component={Applications} />
          <Redirect from="/auth" to={authRoute} />
          <Redirect from="/" to="/apps" />
        </Switch>
      </Layout>
    );
  } else {
    if (!authRoute) {
      dispatch(actions.setAuthRoute(props.location.pathname));
    }
  }
  return <Suspense fallback={suspenseSpinner}>{routeTo}</Suspense>;
};

export default withRouter(App);
