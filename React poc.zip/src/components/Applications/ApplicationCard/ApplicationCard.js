import React from "react";
import Card from "../../UI/Card/Card";
import { useHistory } from "react-router-dom";

const ApplicationCard = (props) => {
  let history = useHistory();

  const openCaseTypes = (id) => {
    history.push(`/apps/${id}/casetypes`);
  };

  const app = props.app;
  const cardConfig = {
    title: app.name,
    showTitle: true,
    showModifyIcon: true,
    showDeleteIcon: true,
    description: app.description,
    clickHandler: openCaseTypes,
    appId: app.id,
  };

  return <Card cardConfig={cardConfig} />;
};

export default ApplicationCard;
