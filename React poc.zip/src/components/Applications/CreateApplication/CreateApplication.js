import React, { useState } from "react";
import Forms from "../../UI/Forms/Forms";
import createAppFormConfig from "./createAppFormConfig";
import Modal from "../../UI/Modal/Modal";
import { useDispatch } from "react-redux";
import { appCreateInit } from "../../../store/actions/application.action";
import ActionCard from "../../UI/Card/ActionCard";
import {
  createUIElemFromConfig,
  preparePayloadFromForm,
} from "../../Util/Util";

const CreateApplication = (props) => {
  const [createAppForm, setCreateAppForm] = useState(createAppFormConfig);
  const dispatch = useDispatch();

  const initAppCreate = () => {
    dispatch(appCreateInit());
  };

  const createAppHandler = () => {
    const appDetails = preparePayloadFromForm(createAppForm);
    props.createHandler(appDetails);
    setCreateAppForm(createAppFormConfig);
  };

  const cancelCreateAppHandler = (e) => {
    //e.preventDefault();
    setCreateAppForm(createAppFormConfig);
    props.cancelHandler();
  };

  const formData = createUIElemFromConfig(createAppForm, setCreateAppForm);

  const createCard = (
    <ActionCard label="New Application" clickHandler={initAppCreate} />
  );

  let createModal = null;
  if (props.isCreatingApp) {
    const formConfig = {
      showSubmit: false,
      showCancel: false,
      errors: props.errors,
    };
    const modalConfig = {
      title: "Create application",
      submitHandler: createAppHandler,
      cancelHandler: cancelCreateAppHandler,
      submitBtnLabel: "Create",
      cancelBtnLabel: "Cancel",
      showSubmit: true,
      showCancel: true,
      disableSubmit: !createAppForm.isValid,
    };
    createModal = (
      <Modal modalConfig={modalConfig}>
        <Forms formConfig={formConfig}>{formData}</Forms>
      </Modal>
    );
  }

  return (
    <React.Fragment>
      {createCard}
      {createModal}
    </React.Fragment>
  );
};

export default CreateApplication;
