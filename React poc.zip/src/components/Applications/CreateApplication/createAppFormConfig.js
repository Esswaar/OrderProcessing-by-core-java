const createAppForm = () => {
  return {
    config: {
      appName: {
        elementType: "input",
        elementConfig: {
          type: "text",
          placeholder: "Application name",
          context: "name",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
      appDescription: {
        elementType: "textarea",
        elementConfig: {
          type: "text",
          placeholder: "App description",
          context: "description",
        },
        value: "",
        validation: {
          required: false,
        },
        valid: true,
        touched: false,
      },
    },
    isValid: false,
  };
};

export default createAppForm;
