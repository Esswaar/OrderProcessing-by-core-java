import React, { useContext, useEffect, useState } from "react";
import Modal from "../../UI/Modal/Modal";
import entityFormConfig from "./EntityForm.config";
import stageNewConfig from "./Stage/StageNew.config";
import stageExistingConfig from "./Stage/StageExisting.config";
import processNewConfig from "./Process/ProcessNew.config";
import processExistingConfig from "./Process/ProcessExisting.config";
import stepNewConfig from "./Step/StepNew.config";
import stepExistingConfig from "./Step/StepExisting.config";
import { createUIElemFromConfig } from "../../Util/Util";
import { useDispatch } from "react-redux";
import { addEntity } from "../../../store/actions/casetypeDetail.action";
import CaseTypeContext from "../../../container/CaseTypeDetail/CaseTypeDetail.context";

const AddEntity = (props) => {
  const casetypeDetail = useContext(CaseTypeContext);

  const [entityForm, setEntityForm] = useState(entityFormConfig);

  const { type } = props;
  const [newFormConfig, existingFormConfig] = getNewFormConfig(type);
  const [newForm, setNewForm] = useState(newFormConfig);
  const [existingForm, setExistingForm] = useState(existingFormConfig);

  const loadExistingEntities = () => {
    if (!isNewForm(entityForm)) {
      const entities = getExistingEntities(type, casetypeDetail);
      const clone = require("rfdc")();
      const updatedExistingForm = clone(existingForm);
      const updatedExistingFormConfig = updatedExistingForm.config;
      const options = updatedExistingFormConfig[type].elementConfig.options;
      updatedExistingFormConfig[type].elementConfig.options = options.concat(
        entities
      );
      setExistingForm(updatedExistingForm);
    }
  };

  useEffect(loadExistingEntities, []);

  const dispatch = useDispatch();

  const createEntityHandler = () => {
    const stageDetails = getEntityDetails(
      props,
      entityForm,
      newForm,
      existingForm
    );
    dispatch(addEntity(stageDetails));
    cancelCreateEntity();
  };

  const cancelCreateEntity = () => {
    props.cancelled();
    setEntityForm(entityFormConfig);
    setNewForm(newFormConfig);
    setExistingForm(existingFormConfig);
  };

  const modalConfig = {
    title: getLabel(type),
    submitHandler: createEntityHandler,
    cancelHandler: cancelCreateEntity,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
  };

  const createModal = () => {
    let uiElems = createUIElemFromConfig(entityForm, setEntityForm);
    let [targetForm, setTargetForm] = isNewForm(entityForm)
      ? [newForm, setNewForm]
      : [existingForm, setExistingForm];
    uiElems = uiElems.concat(createUIElemFromConfig(targetForm, setTargetForm));
    modalConfig.disableSubmit = !targetForm.isValid;
    return <Modal modalConfig={modalConfig}>{uiElems}</Modal>;
  };

  return <>{createModal()}</>;
};

const getLabel = (type) => {
  const add = "Add ";
  switch (type) {
    case "stage":
      return `${add}stage`;
    case "process":
      return `${add}process`;
    case "step":
      return `${add}step`;
    default:
      return null;
  }
};

const getNewFormConfig = (type) => {
  switch (type) {
    case "stage":
      return [stageNewConfig, stageExistingConfig];
    case "process":
      return [processNewConfig, processExistingConfig];
    case "step":
      return [stepNewConfig, stepExistingConfig];
    default:
      return null;
  }
};

const getEntityDetails = (props, entityForm, newForm, existingForm) => {
  let entityDetails = null;
  if (isNewForm(entityForm)) {
    entityDetails = {
      _status: "new",
      id: Date.now(),
    };
    const formConfig = newForm.config;
    for (let id in formConfig) {
      const elem = formConfig[id];
      entityDetails[elem.elementConfig.context] = elem.value;
    }
  } else {
    entityDetails = {
      _status: "existing",
      id: existingForm.config[props.type].value,
    };
  }
  entityDetails["config"] = props;
  return entityDetails;
};

const getExistingEntities = (type, casetypeDetail) => {
  switch (type) {
    case "stage":
      return prepareExistingEntities(casetypeDetail._stages);
    case "process":
      return prepareExistingEntities(casetypeDetail._processes);
    case "step":
      return prepareExistingEntities(casetypeDetail._steps);
    default:
      return null;
  }
};

const prepareExistingEntities = (entities) => {
  const resultEntities = [];
  if (entities) {
    Object.values(entities).forEach((entity) => {
      if (!entity._status) {
        resultEntities.push({ id: entity.id, displayValue: entity.name });
      }
    });
  }
  return resultEntities;
};

const isNewForm = (entityForm) => {
  return entityForm.config.createOption.value === "new";
};

export default AddEntity;
