const entityFormConfig = () => {
  return {
    config: {
      createOption: {
        elementType: "radioButtonGroup",
        elementConfig: {
          type: "text",
          values: [
            { id: "existing", displayValue: "Use existing" },
            { id: "new", displayValue: "New" },
          ],
          placeholder: "Choose option",
          context: "createOption",
        },
        value: "existing",
        validation: {
          required: false,
        },
        valid: true,
        touched: false,
      },
    },
    isValid: false,
  };
};

export default entityFormConfig;
