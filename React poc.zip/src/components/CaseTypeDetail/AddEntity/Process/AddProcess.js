import React, { useContext, useEffect, useState } from "react";
import CaseTypeContext from "../../../../container/CaseTypeDetail/CaseTypeDetail.context";
import entityFormConfig from "../EntityForm.config";
import processNewConfig from "./ProcessNew.config";
import processExistingConfig from "./ProcessExisting.config";
import {
  createUIElemFromConfig,
  getEntityDetails,
  getLabel,
  isNewForm,
  prepareExistingEntities,
  updateFormWithExistingEntities,
} from "../../../Util/Util";
import { useDispatch } from "react-redux";
import { addEntity } from "../../../../store/actions/casetypeDetail.action";
import Modal from "../../../UI/Modal/Modal";

const AddProcess = (props) => {
  const casetypeDetail = useContext(CaseTypeContext);

  const [entityForm, setEntityForm] = useState(entityFormConfig);
  const [newForm, setNewForm] = useState(processNewConfig);
  const [existingForm, setExistingForm] = useState(processExistingConfig);

  const loadExistingEntities = () => {
    if (!isNewForm(entityForm)) {
      const entities = prepareExistingEntities(casetypeDetail._processes);
      const form = updateFormWithExistingEntities(
        existingForm,
        "process",
        entities
      );
      setExistingForm(form);
    }
  };

  useEffect(loadExistingEntities, []);

  const dispatch = useDispatch();

  const createEntityHandler = () => {
    const processDetails = getEntityDetails(
      props,
      entityForm,
      newForm,
      existingForm
    );
    dispatch(addEntity(processDetails));
    cancelCreateEntity();
  };

  const cancelCreateEntity = () => {
    props.cancelled();
    setEntityForm(entityFormConfig);
    setNewForm(processNewConfig);
    setExistingForm(processExistingConfig);
  };

  const modalConfig = {
    title: getLabel("process"),
    submitHandler: createEntityHandler,
    cancelHandler: cancelCreateEntity,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
  };

  const createModal = () => {
    let uiElems = createUIElemFromConfig(entityForm, setEntityForm);
    let [targetForm, setTargetForm] = isNewForm(entityForm)
      ? [newForm, setNewForm]
      : [existingForm, setExistingForm];
    uiElems = uiElems.concat(createUIElemFromConfig(targetForm, setTargetForm));
    modalConfig.disableSubmit = !targetForm.isValid;
    return <Modal modalConfig={modalConfig}>{uiElems}</Modal>;
  };

  return <>{createModal()}</>;
};

export default AddProcess;
