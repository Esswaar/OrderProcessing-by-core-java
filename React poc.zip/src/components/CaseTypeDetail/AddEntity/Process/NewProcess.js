import React, {useState} from "react";
import AddIcon from "../../../UI/AddIcon/AddIcon";
import AddProcess from "./AddProcess";

const NewProcess = (props) => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const newProcessModal = showModal ? (
    <AddProcess type="process" cancelled={closeModal} stageID={props.id} />
  ) : null;

  return (
    <React.Fragment>
      {createProcess(openModal, props.viewType)}
      {newProcessModal}
    </React.Fragment>
  );
};

const createProcess = (openModal, viewType) => {
  return (
    <AddIcon onClickHandler={openModal} label="process" viewType={viewType} />
  );
};

export default NewProcess;
