const processExistingConfig = () => {
  return {
    config: {
      process: {
        elementType: "select",
        elementConfig: {
          options: [{ id: "", displayValue: "--- Select process---" }],
          placeholder: "Existing process",
          context: "id",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
    },
    isValid: false,
  };
};

export default processExistingConfig;
