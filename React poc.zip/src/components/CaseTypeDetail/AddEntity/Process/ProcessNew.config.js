const processNewConfig = () => {
  return {
    config: {
      name: {
        elementType: "input",
        elementConfig: {
          type: "text",
          placeholder: "Process name",
          context: "name",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
      description: {
        elementType: "textarea",
        elementConfig: {
          type: "text",
          placeholder: "Process description",
          context: "description",
        },
        value: "",
        validation: {
          required: false,
        },
        valid: true,
        touched: false,
      },
    },
    isValid: false,
  };
};

export default processNewConfig;
