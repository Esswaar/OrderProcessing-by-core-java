import React, { useContext, useEffect, useState } from "react";
import CaseTypeContext from "../../../../container/CaseTypeDetail/CaseTypeDetail.context";
import entityFormConfig from "../EntityForm.config";
import stageNewConfig from "./StageNew.config";
import stageExistingConfig from "./StageExisting.config";
import { useDispatch } from "react-redux";
import { addEntity } from "../../../../store/actions/casetypeDetail.action";
import Modal from "../../../UI/Modal/Modal";
import {
  createUIElemFromConfig,
  getEntityDetails,
  getLabel,
  isNewForm,
  prepareExistingEntities,
  updateFormWithExistingEntities,
} from "../../../Util/Util";

const AddStage = (props) => {
  const casetypeDetail = useContext(CaseTypeContext);

  const [entityForm, setEntityForm] = useState(entityFormConfig);
  const [newForm, setNewForm] = useState(stageNewConfig);
  const [existingForm, setExistingForm] = useState(stageExistingConfig);

  const loadExistingEntities = () => {
    if (!isNewForm(entityForm)) {
      const entities = prepareExistingEntities(casetypeDetail._stages);
      const form = updateFormWithExistingEntities(
        existingForm,
        "stage",
        entities
      );
      setExistingForm(form);
    }
  };
  useEffect(loadExistingEntities, []);

  const dispatch = useDispatch();
  const createEntityHandler = () => {
    const stageDetails = getEntityDetails(
      props,
      entityForm,
      newForm,
      existingForm
    );
    dispatch(addEntity(stageDetails));
    cancelCreateEntity();
  };

  const cancelCreateEntity = () => {
    props.cancelled();
    setEntityForm(entityFormConfig);
    setNewForm(stageNewConfig);
    setExistingForm(stageExistingConfig);
  };

  const modalConfig = {
    title: getLabel("stage"),
    submitHandler: createEntityHandler,
    cancelHandler: cancelCreateEntity,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
  };

  const createModal = () => {
    let uiElems = createUIElemFromConfig(entityForm, setEntityForm);
    let [targetForm, setTargetForm] = isNewForm(entityForm)
      ? [newForm, setNewForm]
      : [existingForm, setExistingForm];
    uiElems = uiElems.concat(createUIElemFromConfig(targetForm, setTargetForm));
    modalConfig.disableSubmit = !targetForm.isValid;
    return <Modal modalConfig={modalConfig}>{uiElems}</Modal>;
  };

  return <>{createModal()}</>;
};

export default AddStage;
