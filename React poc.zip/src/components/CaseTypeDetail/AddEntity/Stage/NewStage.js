import React, {useState} from "react";
import AddIcon from "../../../UI/AddIcon/AddIcon";
import AddStage from "./AddStage";

const NewStage = (props) => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const newStageModal = showModal ? (
    <AddStage type="stage" cancelled={closeModal} />
  ) : null;

  return (
    <React.Fragment>
      {createStage(openModal, props.viewType)}
      {newStageModal}
    </React.Fragment>
  );
};

const createStage = (openModal, viewType) => {
  return (
    <AddIcon onClickHandler={openModal} label="stage" viewType={viewType} />
  );
};

export default NewStage;
