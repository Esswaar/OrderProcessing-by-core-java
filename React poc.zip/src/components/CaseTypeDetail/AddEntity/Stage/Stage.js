import React, { useState } from "react";
import AddIcon from "../../../UI/AddIcon/AddIcon";
import Modal from "../../../UI/Modal/Modal";
import stageNewConfig from "./StageNew.config";
import stageExistingConfig from "./StageExisting.config";
import entityFormConfig from "../EntityForm.config";
import { useDispatch } from "react-redux";
import { addEntity } from "../../../../store/actions/casetypeDetail.action";
import {
  createUIElemFromConfig,
  isNewForm,
  getEntityDetails,
} from "../../../Util/Util";

const Stage = (props) => {
  const [entityForm, setEntityForm] = useState(entityFormConfig);
  const [newForm, setNewForm] = useState(stageNewConfig);
  const [existingForm, setExistingForm] = useState(stageExistingConfig);
  const [showModal, setShowModal] = useState(false);

  const dispatch = useDispatch();

  const openModal = () => {
    setShowModal(true);
  };

  const createEntityHandler = () => {
    const stageDetails = getEntityDetails(
      { type: "stage" },
      entityForm,
      newForm,
      existingForm
    );
    dispatch(addEntity(stageDetails));
    cancelCreateEntity();
  };

  const cancelCreateEntity = () => {
    setShowModal(false);
    setEntityForm(entityFormConfig);
    setExistingForm(stageExistingConfig);
    setNewForm(stageNewConfig);
  };

  const createEntity = () => {
    return <AddIcon onClickHandler={openModal} label="Add Stage" />;
  };

  const modalConfig = {
    title: "Add stage",
    submitHandler: createEntityHandler,
    cancelHandler: cancelCreateEntity,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
  };

  const createModal = () => {
    if (showModal) {
      let uiElems = createUIElemFromConfig(entityForm, setEntityForm);
      let [targetForm, setTargetForm] = isNewForm(entityForm)
        ? [newForm, setNewForm]
        : [existingForm, setExistingForm];
      uiElems = uiElems.concat(
        createUIElemFromConfig(targetForm, setTargetForm)
      );
      modalConfig.disableSubmit = !targetForm.isValid;
      return <Modal modalConfig={modalConfig}>{uiElems}</Modal>;
    } else {
      return null;
    }
  };
  return (
    <>
      {createEntity()}
      {createModal()}
    </>
  );
};

export default Stage;
