const stageExistingConfig = () => {
  return {
    config: {
      stage: {
        elementType: "select",
        elementConfig: {
          options: [{ id: "", displayValue: "--- Select stage---" }],
          placeholder: "Existing stage",
          context: "id",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
    },
    isValid: false,
  };
};

export default stageExistingConfig;
