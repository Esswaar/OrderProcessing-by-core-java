import React from "react";
import Process from "../../ListView/Process";
import ProcessCV from "../../CardView/Process";

export const getProcesses = (stage, casetypeDetail, isListView) => {
  if (stage.processes) {
    return stage.processes.map((process, index) => {
      if (process._status === "deleted") {
        return null;
      }
      const id = process.id;
      const detail = casetypeDetail["_processes"][id];
      if (!detail) {
        return null;
      }

      const config = {
        key: `${id}_${index}`,
        casetypeDetail: casetypeDetail,
        processDetails: detail,
        stageID: stage.id,
      };
      const target = isListView ? (
        <Process {...config} />
      ) : (
        <ProcessCV {...config} />
      );

      return target;
    });
  }
  return null;
};
