import React, { useEffect, useState } from "react";
import stepNewConfig from "./StepNew.config";
import Modal from "../../../UI/Modal/Modal";
import {
  createUIElemFromConfig,
  getNewFormEntityDetails,
  getLabel,
  getStepTypes,
  getOperators,
} from "../../../Util/Util";
import { addEntity } from "../../../../store/actions/casetypeDetail.action";
import { useDispatch } from "react-redux";

const AddStep = (props) => {
  const [newForm, setNewForm] = useState(stepNewConfig);

  const loadStepOptions = () => {
    const stepTypes = getStepTypes();
    const routeOprs = getOperators();

    const clone = require("rfdc")();
    const updatedForm = clone(newForm);
    const updatedFormConfig = updatedForm.config;

    const typeOptions = updatedFormConfig["type"].elementConfig.options;
    updatedFormConfig["type"].elementConfig.options = typeOptions.concat(
      stepTypes
    );

    const routeOptions = updatedFormConfig["routeTo"].elementConfig.options;
    updatedFormConfig["routeTo"].elementConfig.options = routeOptions.concat(
      routeOprs
    );

    setNewForm(updatedForm);
  };

  useEffect(loadStepOptions, []);

  const dispatch = useDispatch();
  const createEntityHandler = () => {
    const stepDetails = getNewFormEntityDetails(props, newForm);
    dispatch(addEntity(stepDetails));
    cancelCreateEntity();
  };

  const cancelCreateEntity = () => {
    props.cancelled();
    setNewForm(stepNewConfig);
  };

  const modalConfig = {
    title: getLabel("step"),
    submitHandler: createEntityHandler,
    cancelHandler: cancelCreateEntity,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
    disableSubmit: !newForm.isValid,
  };

  const uiElems = createUIElemFromConfig(newForm, setNewForm);
  return <Modal modalConfig={modalConfig}>{uiElems}</Modal>;
};

export default AddStep;
