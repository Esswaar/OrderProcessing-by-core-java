import React, {useState} from "react";
import AddIcon from "../../../UI/AddIcon/AddIcon";
import AddStep from "./AddStep";

const NewStep = (props) => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const newStepModal = showModal ? (
    <AddStep type="step" cancelled={closeModal} processID={props.id} />
  ) : null;

  return (
    <React.Fragment>
      {createStep(openModal, props.viewType)}
      {newStepModal}
    </React.Fragment>
  );
};

const createStep = (openModal, viewType) => {
  return (
    <AddIcon onClickHandler={openModal} label="step" viewType={viewType} />
  );
};

export default NewStep;
