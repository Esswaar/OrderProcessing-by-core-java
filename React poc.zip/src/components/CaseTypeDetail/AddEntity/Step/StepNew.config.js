const stepNewConfig = () => {
  return {
    config: {
      name: {
        elementType: "input",
        elementConfig: {
          type: "text",
          placeholder: "Step name",
          context: "name",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
      type: {
        elementType: "select",
        elementConfig: {
          options: [{ id: "", displayValue: " --- Select type---" }],
          placeholder: "Step type",
          context: "type",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
      routeTo: {
        elementType: "select",
        elementConfig: {
          options: [{ id: "", displayValue: " --- Select route to ---" }],
          placeholder: "Route to",
          context: "routeTo",
        },
        value: "",
        validation: {
          required: false,
        },
        valid: true,
        touched: false,
      },
      status: {
        elementType: "input",
        elementConfig: {
          type: "text",
          placeholder: "Status",
          context: "status",
        },
        value: "",
        validation: {
          required: false,
        },
        valid: true,
        touched: false,
      },
    },
    isValid: false,
  };
};

export default stepNewConfig;
