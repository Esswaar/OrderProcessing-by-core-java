import React from "react";
import classes from "./CardView.module.css";
import ListActions from "../../UI/List/ListActions";

const EntityLabel = (props) => {
  const { name, className, showEdit, showDelete } = props;
  //const classNames = [className];
  //classNames.push(classes.entityName);
  const label = (
    <div className={className}>
      <div className={classes.name} onClick={showEdit}>
        {name}
      </div>
      <div className={classes.action}>
        <ListActions
          className={classes.action}
          showDelete={true}
          showDeleteHandler={showDelete}
        />
      </div>
    </div>
  );
  return label;
};

export default EntityLabel;
