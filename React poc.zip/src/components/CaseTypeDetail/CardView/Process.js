import React, { useState } from "react";
import Step from "./Step";
import classes from "./CardView.module.css";
import NewStep from "../AddEntity/Step/NewStep";
import DeleteEntity from "../DeleteEntity/DeleteEntity";
import EditProcess from "../EditEntity/Process/Process";
import EntityLabel from "./EntityLabel";

const Process = (props) => {
  const { casetypeDetail } = props;
  const process = props.processDetails;
  const initialState = { showModal: false, operation: null };
  const [config, setConfig] = useState(initialState);
  const showEdit = () => setConfig({ showModal: true, operation: "edit" });
  const showDelete = () => setConfig({ showModal: true, operation: "delete" });
  const cancelEditOrDelete = () => setConfig(initialState);

  let modal = null;
  if (config.showModal) {
    const editModalConfig = { cancelled: cancelEditOrDelete, process: process };
    const deleteModalConfig = {
      cancelled: cancelEditOrDelete,
      id: process.id,
      type: "process",
      parentId: props.stageID,
    };
    modal =
      config.operation === "edit" ? (
        <EditProcess {...editModalConfig} />
      ) : (
        <DeleteEntity {...deleteModalConfig} />
      );
  }

  const label = (
    <EntityLabel
      name={process.name}
      className={classes.processName}
      showEdit={showEdit}
      showDelete={showDelete}
    />
  );

  return (
    <React.Fragment>
      <div className={classes.process}>
        {label}
        <div className={classes.steps}>
          {getSteps(casetypeDetail, process)}
          <div className={classes.addStep}>
            <NewStep id={process.id} viewType="card" />
          </div>
        </div>
      </div>
      {modal}
    </React.Fragment>
  );
};

const getSteps = (casetypeDetail, process) => {
  if (process && process.steps) {
    return process.steps.map((step, index) => {
      if (step._status === "deleted") {
        return null;
      }
      const id = step.id;
      const detail = casetypeDetail["_steps"][id];
      if (!detail) {
        return null;
      }

      return (
        <Step
          key={`${id}_${index}`}
          casetypeDetail={casetypeDetail}
          stepDetails={detail}
          processID={process.id}
        />
      );
    });
  }
  return null;
};

export default Process;
