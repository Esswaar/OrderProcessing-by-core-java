import React, { useContext, useState } from "react";
import { getProcesses } from "../AddEntity/Stage/Util";
import classes from "./CardView.module.css";
import EditStage from "../EditEntity/Stage/Stage";
import DeleteEntity from "../DeleteEntity/DeleteEntity";
import NewProcess from "../AddEntity/Process/NewProcess";
import CaseTypeContext from "../../../container/CaseTypeDetail/CaseTypeDetail.context";
import EntityLabel from "./EntityLabel";

const Stage = (props) => {
  const stage = props.stageDetails;
  const casetypeDetail = useContext(CaseTypeContext);
  const initialState = { showModal: false, operation: null };
  const [config, setConfig] = useState(initialState);

  const showEdit = () => setConfig({ showModal: true, operation: "edit" });
  const showDelete = () => setConfig({ showModal: true, operation: "delete" });
  const cancelEditOrDelete = () => setConfig(initialState);

  let modal = null;
  if (config.showModal) {
    const editModalConfig = { cancelled: cancelEditOrDelete, stage: stage };
    const deleteModalConfig = {
      cancelled: cancelEditOrDelete,
      id: stage.id,
      type: "stage",
    };
    modal =
      config.operation === "edit" ? (
        <EditStage {...editModalConfig} />
      ) : (
        <DeleteEntity {...deleteModalConfig} />
      );
  }

  const addProcess = (
    <div className={classes.addProcess}>
      <NewProcess id={stage.id} viewType="card" />
    </div>
  );

  const label = (
    <EntityLabel
      name={stage.name}
      className={classes.stageName}
      showEdit={showEdit}
      showDelete={showDelete}
    />
  );

  return (
    <React.Fragment>
      <div className={classes.stage}>
        {label}
        <div className={classes.processes}>
          {getProcesses(stage, casetypeDetail)}
          {addProcess}
        </div>
      </div>
      {modal}
    </React.Fragment>
  );
};

export default Stage;
