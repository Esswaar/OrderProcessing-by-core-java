import React, { useState } from "react";
import EditStep from "../EditEntity/Step/Step";
import DeleteEntity from "../DeleteEntity/DeleteEntity";
import EntityLabel from "./EntityLabel";
import classes from "./CardView.module.css";

const Step = (props) => {
  const step = props.stepDetails;
  const initialState = { showModal: false, operation: null };
  const [config, setConfig] = useState(initialState);
  const showEdit = () => setConfig({ showModal: true, operation: "edit" });
  const showDelete = () => setConfig({ showModal: true, operation: "delete" });
  const cancelEditOrDelete = () => setConfig(initialState);

  let modal = null;
  if (config.showModal) {
    const editModalConfig = { cancelled: cancelEditOrDelete, step: step };
    const deleteModalConfig = {
      cancelled: cancelEditOrDelete,
      id: step.id,
      type: "step",
      parentId: props.processID,
    };
    modal =
      config.operation === "edit" ? (
        <EditStep {...editModalConfig} />
      ) : (
        <DeleteEntity {...deleteModalConfig} />
      );
  }

  const label = (
    <EntityLabel
      name={step.name}
      className={classes.processName}
      showEdit={showEdit}
      showDelete={showDelete}
    />
  );

  return (
    <div className={classes.step}>
      {label}
      {modal}
    </div>
  );
};

export default Step;
