import React from "react";
import { useDispatch } from "react-redux";
import Modal from "../../UI/Modal/Modal";
import { deleteEntity } from "../../../store/actions/casetypeDetail.action";
import { getLabel } from "../../Util/Util";

const DeleteEntity = (props) => {
  const { id, type, parentId } = props;
  const dispatch = useDispatch();

  const doDelete = () => {
    dispatch(deleteEntity({ _config: { id: id, type: type, parentId: parentId} }));
    cancelDelete();
  };

  const cancelDelete = () => {
    props.cancelled();
  };

  const modalConfig = {
    title: getLabel(type, "delete"),
    submitHandler: doDelete,
    cancelHandler: cancelDelete,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
  };

  return (
    <Modal modalConfig={modalConfig}>
      <div style={{ textAlign: "left" }}>Are you sure?</div>
    </Modal>
  );
};

export default DeleteEntity;
