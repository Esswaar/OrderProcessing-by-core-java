import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import processNewConfig from "../../AddEntity/Process/ProcessNew.config";
import Modal from "../../../UI/Modal/Modal";
import { editEntity } from "../../../../store/actions/casetypeDetail.action";
import {
  updateEntityDetails,
  createUIElemFromConfig,
  getLabel,
  prepareEditForm,
} from "../../../Util/Util";

const Process = (props) => {
  const [editForm, setEditForm] = useState(processNewConfig);

  const initForm = () => {
    setEditForm(prepareEditForm(editForm, props.process));
  };

  useEffect(initForm, []);

  const dispatch = useDispatch();

  const editProcess = () => {
    const processDetails = updateEntityDetails(
      "process",
      props.process.id,
      editForm
    );
    dispatch(editEntity(processDetails));
    cancelEditProcess();
  };

  const cancelEditProcess = () => {
    props.cancelled();
    setEditForm(processNewConfig);
  };

  const modalConfig = {
    title: getLabel("process", "edit"),
    submitHandler: editProcess,
    cancelHandler: cancelEditProcess,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
    disableSubmit: !editForm.isValid,
  };

  const uiElems = createUIElemFromConfig(editForm, setEditForm);
  return <Modal modalConfig={modalConfig}>{uiElems}</Modal>;
};

export default Process;
