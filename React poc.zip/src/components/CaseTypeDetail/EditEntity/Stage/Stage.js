import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import stageNewConfig from "../../AddEntity/Stage/StageNew.config";
import Modal from "../../../UI/Modal/Modal";
import { editEntity } from "../../../../store/actions/casetypeDetail.action";
import {
  updateEntityDetails,
  createUIElemFromConfig,
  getLabel,
  prepareEditForm,
} from "../../../../components/Util/Util";

const Stage = (props) => {
  const [editForm, setEditForm] = useState(stageNewConfig);

  const initForm = () => {
    setEditForm(prepareEditForm(editForm, props.stage));
  };

  useEffect(initForm, []);

  const dispatch = useDispatch();

  const editStage = () => {
    const stageDetails = updateEntityDetails("stage", props.stage.id, editForm);
    dispatch(editEntity(stageDetails));
    cancelEditStage();
  };

  const cancelEditStage = () => {
    props.cancelled();
    setEditForm(stageNewConfig);
  };

  const modalConfig = {
    title: getLabel("stage", "edit"),
    submitHandler: editStage,
    cancelHandler: cancelEditStage,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
    disableSubmit: !editForm.isValid,
  };

  const uiElems = createUIElemFromConfig(editForm, setEditForm);
  return <Modal modalConfig={modalConfig}>{uiElems}</Modal>;
};

export default Stage;
