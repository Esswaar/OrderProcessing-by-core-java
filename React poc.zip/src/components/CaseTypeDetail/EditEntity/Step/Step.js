import React, { useEffect, useState } from "react";
import stepNewConfig from "../../AddEntity/Step/StepNew.config";
import { useDispatch } from "react-redux";
import { editEntity } from "../../../../store/actions/casetypeDetail.action";
import {
  createUIElemFromConfig,
  getLabel,
  getOperators,
  getStepTypes,
  updateEntityDetails,
  prepareEditForm,
} from "../../../Util/Util";
import Modal from "../../../UI/Modal/Modal";

const Step = (props) => {
  const [editForm, setEditForm] = useState(stepNewConfig);

  const initForm = () => {
    const updatedEditForm = prepareEditForm(editForm, props.step);
    const config = updatedEditForm.config;

    const typeOptions = config["type"].elementConfig.options;
    config["type"].elementConfig.options = typeOptions.concat(getStepTypes());

    const routeOptions = config["routeTo"].elementConfig.options;
    config["routeTo"].elementConfig.options = routeOptions.concat(
      getOperators()
    );

    setEditForm(updatedEditForm);
  };

  useEffect(initForm, []);
  const dispatch = useDispatch();
  const editStep = () => {
    const stepDetails = updateEntityDetails("step", props.step.id, editForm);
    dispatch(editEntity(stepDetails));
    cancelEditStep();
  };

  const cancelEditStep = () => {
    props.cancelled();
    setEditForm(stepNewConfig);
  };
  const modalConfig = {
    title: getLabel("step", "edit"),
    submitHandler: editStep,
    cancelHandler: cancelEditStep,
    submitBtnLabel: "Submit",
    cancelBtnLabel: "Cancel",
    showSubmit: true,
    showCancel: true,
    disableSubmit: !editForm.isValid,
    disableCancel: false,
  };

  const uiElems = createUIElemFromConfig(editForm, setEditForm);
  return <Modal modalConfig={modalConfig}>{uiElems}</Modal>;
};

export default Step;
