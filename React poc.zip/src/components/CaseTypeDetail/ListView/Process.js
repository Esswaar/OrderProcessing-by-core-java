import React, {useState} from "react";
import Step from "./Step";
import List from "../../UI/List/List";
import NewStep from "../AddEntity/Step/NewStep";
import EditProcess from "../EditEntity/Process/Process";
import DeleteEntity from "../DeleteEntity/DeleteEntity";

const Process = (props) => {
    const {casetypeDetail} = props;
    const processes = props.processDetails;
    const initialState = {showModal: false, operation: null};
    const [config, setConfig] = useState(initialState);
    const showEdit = () => setConfig({showModal: true, operation: "edit"});
    const showDelete = () => setConfig({showModal: true, operation: "delete"});
    const cancelEditOrDelete = () => setConfig(initialState);

    let modal = null;
    if (config.showModal) {
        const editModalConfig = {cancelled: cancelEditOrDelete, process: processes};
        const deleteModalConfig = {
            cancelled: cancelEditOrDelete,
            id: processes.id,
            type: "process",
            parentId: props.stageID,
        };
        modal =
            config.operation === "edit" ? (
                <EditProcess {...editModalConfig} />
            ) : (
                <DeleteEntity {...deleteModalConfig} />
            );
    }

    return (
        <React.Fragment>
            <List type="process" label={processes.name}
                  showEdit={showEdit}
                  showDelete={showDelete}>
                <ul>{getSteps(casetypeDetail, processes)}</ul>
                <NewStep id={processes.id}/>
            </List>
            {modal}
        </React.Fragment>
    );
};

const getSteps = (casetypeDetail, processes) => {
    if (processes && processes.steps) {
        return processes.steps.map((step, index) => {
            if (step._status === "deleted") {
                return null;
            }
            const id = step.id;
            const detail = casetypeDetail["_steps"][id];
            return (
                <Step
                    key={`${id}_${index}`}
                    casetypeDetail={casetypeDetail}
                    stepDetails={detail}
                    processId={processes.id}
                />
            );
        });
    }
};

export default Process;
