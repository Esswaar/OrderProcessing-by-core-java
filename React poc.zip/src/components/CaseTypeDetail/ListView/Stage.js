import React, { useContext, useState } from "react";
import { getProcesses } from "../AddEntity/Stage/Util";
import List from "../../UI/List/List";
import NewProcess from "../AddEntity/Process/NewProcess";
import EditStage from "../EditEntity/Stage/Stage";
import DeleteEntity from "../DeleteEntity/DeleteEntity";
import CaseTypeContext from "../../../container/CaseTypeDetail/CaseTypeDetail.context";

const Stage = (props) => {
  const stage = props.stageDetails;
  const casetypeDetail = useContext(CaseTypeContext);
  const initialState = { showModal: false, operation: null };
  const [config, setConfig] = useState(initialState);

  const showEdit = () => setConfig({ showModal: true, operation: "edit" });
  const showDelete = () => setConfig({ showModal: true, operation: "delete" });
  const cancelEditOrDelete = () => setConfig(initialState);

  let modal = null;
  if (config.showModal) {
    const editModalConfig = { cancelled: cancelEditOrDelete, stage: stage };
    const deleteModalConfig = {
      cancelled: cancelEditOrDelete,
      id: stage.id,
      type: "stage",
    };
    modal =
      config.operation === "edit" ? (
        <EditStage {...editModalConfig} />
      ) : (
        <DeleteEntity {...deleteModalConfig} />
      );
  }

  return (
    <React.Fragment>
      <List
        label={stage.name}
        type="stage"
        showEdit={showEdit}
        showDelete={showDelete}
      >
        <ol>{getProcesses(stage, casetypeDetail, true)}</ol>
        <NewProcess id={stage.id} />
      </List>
      {modal}
    </React.Fragment>
  );
};

export default Stage;
