import React, {useState} from "react";
import List from "../../UI/List/List";
import DeleteEntity from "../DeleteEntity/DeleteEntity";
import EditStep from "../EditEntity/Step/Step";

const Step = (props) => {
    const stepDetails = props.stepDetails;
    const initialState = {showModal: false, operation: null};
    const [config, setConfig] = useState(initialState);
    const showEdit = () => setConfig({showModal: true, operation: "edit"});
    const showDelete = () => setConfig({showModal: true, operation: "delete"});
    const cancelEditOrDelete = () => setConfig(initialState);

    let modal = null;
    if (config.showModal) {
        const editModalConfig = {cancelled: cancelEditOrDelete, step: stepDetails};
        const deleteModalConfig = {
            cancelled: cancelEditOrDelete,
            id: stepDetails.id,
            type: "step",
            parentId:props.processId
        };
        modal =
            config.operation === "edit" ? (
                <EditStep {...editModalConfig} />
            ) : (
                <DeleteEntity {...deleteModalConfig} />
            );
    }
    return (
        <React.Fragment>
            <List label={stepDetails.name}
                  type="step"
                  showEdit={showEdit}
                  showDelete={showDelete}
            >
            </List>
            {modal}
        </React.Fragment>
    );
};

export default Step;
