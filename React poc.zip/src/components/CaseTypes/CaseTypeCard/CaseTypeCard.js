import React from "react";
import Card from "../../UI/Card/Card";
import { useHistory } from "react-router-dom";

const CaseTypeCard = (props) => {
  let history = useHistory();

  const openCaseTypeDetail = (appId,id) => {
    history.push(`/apps/${appId}/casetypes/${id}`);
  };

  const caseType = props.caseType;
  const appInfo = props.appInfo;
  const cardConfig = {
    title: caseType.name,
    showTitle: true,
    showModifyIcon: true,
    showDeleteIcon: true,
    description: caseType.description,
    clickHandler: openCaseTypeDetail,
    id: caseType.id,
    appId : appInfo.id
  };

  return <Card cardConfig={cardConfig} />;
};

export default CaseTypeCard;
