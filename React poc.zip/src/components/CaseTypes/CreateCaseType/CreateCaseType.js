import React, { useState } from "react";
import Forms from "../../UI/Forms/Forms";
import createCaseTypeFormConfig from "./createCaseTypeFormConfig";
import Modal from "../../UI/Modal/Modal";
import { useDispatch } from "react-redux";
import { caseCreateInit } from "../../../store/actions/casetype.action";
import ActionCard from "../../UI/Card/ActionCard";
import {
  createUIElemFromConfig,
  preparePayloadFromForm,
} from "../../Util/Util";

const CreateApplication = (props) => {
  const [form, setForm] = useState(createCaseTypeFormConfig);
  const dispatch = useDispatch();

  const initCaseCreate = () => {
    dispatch(caseCreateInit());
  };

  const createCaseHandler = () => {
    const caseDetails = preparePayloadFromForm(form);
    props.createHandler(caseDetails);
    setForm(createCaseTypeFormConfig);
  };

  const cancelCreateCaseHandler = (e) => {
    //e.preventDefault();
    setForm(createCaseTypeFormConfig);
    props.cancelHandler();
  };

  const formData = createUIElemFromConfig(form, setForm);
  const createCard = (
    <ActionCard label="New case type" clickHandler={initCaseCreate} />
  );

  let createModal = null;
  if (props.isCreatingCaseType) {
    const formConfig = {
      showSubmit: false,
      showCancel: false,
      errors: props.errors,
    };
    const modalConfig = {
      title: "Create case type",
      submitHandler: createCaseHandler,
      cancelHandler: cancelCreateCaseHandler,
      submitBtnLabel: "Create",
      cancelBtnLabel: "Cancel",
      showSubmit: true,
      showCancel: true,
      disableSubmit: !form.isValid,
      disableCancel: false,
    };
    createModal = (
      <Modal modalConfig={modalConfig}>
        <Forms formConfig={formConfig}>{formData}</Forms>
      </Modal>
    );
  }

  return (
    <React.Fragment>
      {createCard}
      {createModal}
    </React.Fragment>
  );
};

export default CreateApplication;
