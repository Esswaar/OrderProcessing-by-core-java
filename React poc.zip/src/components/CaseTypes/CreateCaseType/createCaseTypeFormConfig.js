const createCaseTypeForm = () => {
  return {
    config: {
      name: {
        elementType: "input",
        elementConfig: {
          type: "text",
          placeholder: "Case type name",
          context: "name",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
      description: {
        elementType: "textarea",
        elementConfig: {
          type: "text",
          placeholder: "Case type description",
          context: "description",
        },
        value: "",
        validation: {
          required: false,
        },
        valid: true,
        touched: false,
      },
    },
    isValid: false,
  };
};

export default createCaseTypeForm;
