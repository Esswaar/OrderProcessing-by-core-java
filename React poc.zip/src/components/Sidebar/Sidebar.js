import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { ArrowBarLeft } from "react-bootstrap-icons";
import classes from "./Sidebar.module.css";
import { logout } from "../../store/actions/auth.action";
import brandLogo from "../../assets/pzPegalogo.svg";

const Sidebar = (props) => {
  const isAuthenticated = useSelector((state) =>
    state.auth.token ? true : false
  );

  const dispatch = useDispatch();
  const handleLogout = () => {
    dispatch(logout());
  };

  const logoutBtn = isAuthenticated ? (
    <button className={classes.logoutBtn} onClick={handleLogout}>
      <ArrowBarLeft />
    </button>
  ) : null;

  const bar = (
    <React.Fragment>
      <div className={classes.sidebarTop}>
        <img src={brandLogo} alt="Pegasystems" className={classes.brandLogo} />
      </div>
      <div className={classes.sidebarBottom}>{logoutBtn}</div>
    </React.Fragment>
  );

  return bar;
};

export default Sidebar;
