import React from "react";
import { PlusCircle } from "react-bootstrap-icons";
import classes from "./AddIcon.module.css";

const AddIcon = (props) => {
  const { label, viewType, onClickHandler } = props;

  let icon = null;
  let prefix = "+";

  if (viewType !== "card") {
    icon = circleIcon();
    prefix = "Add";
  }

  const link = (
    <a href={href} onClick={onClickHandler} className={classes.addIcon}>
      {icon} {`${prefix} ${label}`}
    </a>
  );

  return link;
};

const href = "#";
const size = 16;
const circleIcon = () => <PlusCircle size={size} />;

export default AddIcon;
