import React from "react";
import Breadcrumb from "react-bootstrap/Breadcrumb";
import { useHistory } from "react-router-dom";

const Breadcrumbs = (props) => {
  const { appInfo, caseTypeInfo } = props;
  const crumbs = buildBreadcrumb(appInfo, caseTypeInfo);
  const history = useHistory();
  const breadcrumb = crumbs ? (
    <Breadcrumb>{getBreadcrumb(crumbs, history)}</Breadcrumb>
  ) : null;
  return breadcrumb;
};

const getBreadcrumb = (crumbs, history) => {
  const handleCrumbClick = (history, to) => {
    history.push(to);
  };
  return crumbs.map((crumb, index) => {
    const { label, to } = crumb;
    return (
      <Breadcrumb.Item
        key={index}
        href="#"
        active={crumb.active}
        onClick={() => handleCrumbClick(history, to)}
      >
        {label}
      </Breadcrumb.Item>
    );
  });
};

const buildBreadcrumb = (appInfo, caseTypeInfo) => {
  const crumbs = initCrumbs();
  if (appInfo) {
    const { id, name } = appInfo;
    crumbs.push({ label: name, to: `/apps/${id}/casetypes` });

    if (caseTypeInfo) {
      crumbs.push({
        label: caseTypeInfo.name,
        to: `/apps/${id}/casetypes/${caseTypeInfo.id}`,
      });
    }
  }

  crumbs[crumbs.length - 1].active = true;
  return crumbs;
};

const initCrumbs = () => [{ label: "My applications", to: "/apps" }];

export default Breadcrumbs;
