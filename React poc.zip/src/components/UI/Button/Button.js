import React from "react";
import Button from "react-bootstrap/Button";

const button = (props) => {
  const {
    clickHandler,
    clickBtnLabel,
    show,
    disable,
    type,
  } = props.buttonConfig;

  const handleClick = (event) => {
    event.preventDefault();
    clickHandler();
  };

  const btn = show ? (
    <Button variant={type} onClick={handleClick} disabled={disable}>
      {clickBtnLabel}
    </Button>
  ) : null;
  return btn;
};

export default button;
