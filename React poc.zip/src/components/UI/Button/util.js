export const getButtonConfig = (
  clickHandler,
  clickBtnLabel,
  show,
  disable,
  type
) => {
  return {
    clickHandler: clickHandler,
    clickBtnLabel: clickBtnLabel,
    show: show,
    disable: disable,
    type: getType(type),
  };
};

const getType = (type) => {
  switch (type) {
    case "P":
      return "primary";
    case "S":
      return "secondary";
    default:
      return "primary";
  }
};
