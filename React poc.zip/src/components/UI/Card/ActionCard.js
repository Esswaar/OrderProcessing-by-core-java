import React from "react";
import { Card } from "react-bootstrap";
import { Plus } from "react-bootstrap-icons";
import classes from "./Card.module.css";

const actionCard = (props) => {
  const { label, clickHandler } = props;
  return (
    <Card className={classes.card}>
      <Card.Body className={classes.body}>
        <button className={classes.createBtn} onClick={clickHandler}>
          <Plus />
        </button>
        <p>{label}</p>
      </Card.Body>
    </Card>
  );
};

export default actionCard;
