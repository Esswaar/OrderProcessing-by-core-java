import React from "react";
import { Card } from "react-bootstrap";
import { Trash } from "react-bootstrap-icons";
import { Gear } from "react-bootstrap-icons";
import classes from "./Card.module.css";
const card = (props) => {
  const {
    title,
    showTitle,
    showModifyIcon,
    modifyHandler,
    showDeleteIcon,
    deleteHandler,
    description,
    clickHandler,
    id,
    appId,
  } = props.cardConfig;

  const href = "#";
  const size = 16;

  const gearIcon = showModifyIcon ? (
    <a href={href} onClick={modifyHandler}>
      <Gear size={size} />
    </a>
  ) : null;

  const trashIcon = showDeleteIcon ? (
    <a href={href} onClick={deleteHandler}>
      <Trash size={size} />
    </a>
  ) : null;

  const titlePart = showTitle ? (
    <Card.Title>
      <div className={classes.title}>
        <div>{title}</div>
        <div className={classes.action}>
          {gearIcon}
          {trashIcon}
        </div>
      </div>
    </Card.Title>
  ) : null;

  const handleClick = () => {
    //event.preventDefault();
    clickHandler(appId, id);
    //event.stopPropagation();
  };

  return (
    <Card className={classes.card} onClick={() => handleClick()}>
      <Card.Body>
        {titlePart}
        <Card.Text>{description}</Card.Text>
      </Card.Body>
    </Card>
  );
};
export default card;
