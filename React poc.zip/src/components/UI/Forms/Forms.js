import React from "react";
import Form from "react-bootstrap/Form";
import Button from "../Button/Button";
import { getButtonConfig } from "../Button/util";
import Alert from "react-bootstrap/Alert";

const Forms = (props) => {
  const {
    submitHandler,
    cancelHandler,
    submitBtnLabel,
    cancelBtnLabel,
    showSubmit,
    showCancel,
    disableSubmit,
    disableCancel,
    errors,
  } = props.formConfig;

  const submitBtnConfig = getButtonConfig(
    submitHandler,
    submitBtnLabel,
    showSubmit,
    disableSubmit,
    "P"
  );
  const submitBtn = <Button buttonConfig={submitBtnConfig} />;

  const cancelBtnConfig = getButtonConfig(
    cancelHandler,
    cancelBtnLabel,
    showCancel,
    disableCancel,
    "S"
  );
  const cancelBtn = <Button buttonConfig={cancelBtnConfig} />;

  const errorSection = errors ? <Alert className="alertBanner" variant="danger">{errors}</Alert> : null;

  return (
    <React.Fragment>
      <Form>
        {errorSection}
        {props.children}
        {submitBtn}
        {cancelBtn}
      </Form>
    </React.Fragment>
  );
};

export default Forms;
