import React from "react";
import Form from "react-bootstrap/Form";
import classes from "./Input.module.css";

const input = (props) => {
  const { name, value = "", placeholder, changed } = props;

  let inputElement = null;

  switch (props.elementType) {
    case "input":
      inputElement = (
        <Form.Group>
          <Form.Control
            type="text"
            name={name}
            value={value}
            onChange={changed}
            placeholder={placeholder}
          />
        </Form.Group>
      );
      break;
    case "textarea":
      inputElement = (
        <Form.Group>
          <Form.Control
            as="textarea"
            name={name}
            value={value}
            onChange={changed}
            placeholder={placeholder}
            rows={3}
          />
        </Form.Group>
      );
      break;
    case "password":
      inputElement = (
        <Form.Group>
          <Form.Control
            type="password"
            name={name}
            value={value}
            onChange={changed}
            placeholder={placeholder}
          />
        </Form.Group>
      );
      break;
    case "radioButtonGroup":
      inputElement = (
        <Form.Group className={classes.radio}>
          {props.elementConfig.values.map((config, index) => {
            return (
              <Form.Check
                inline
                type="radio"
                key={`${name}_${index}`}
                name={name}
                label={config.displayValue}
                value={config.id}
                onChange={changed}
                defaultChecked={config.id === value}
              />
            );
          })}
        </Form.Group>
      );
      break;
    case "select":
      inputElement = (
        <Form.Group>
          <Form.Control as="select" value={value} onChange={changed} custom>
            {props.elementConfig.options.map((option) => {
              return (
                <option key={option.id} value={option.id}>
                  {option.displayValue}
                </option>
              );
            })}
          </Form.Control>
        </Form.Group>
      );
      break;
    default:
      inputElement = (
        <input {...props.elementConfig} value={value} onChange={changed} />
      );
  }

  return inputElement;
};

export default input;
