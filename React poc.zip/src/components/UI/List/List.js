import React from "react";
import classes from "./List.module.css";
import ListActions from "./ListActions";

const List = (props) => {
  const label = props.label;
  return (
    <li className={classes.list}>
      <div className={classes.label}>
        {label}
        <ListActions
          className={classes.action}
          showEdit={true}
          showEditHandler={props.showEdit}
          showDelete={true}
          showDeleteHandler={props.showDelete}
        />
      </div>

      <div>{props.children}</div>
    </li>
  );
};

export default List;
