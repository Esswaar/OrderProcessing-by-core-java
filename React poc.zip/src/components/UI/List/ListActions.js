import React from "react";
import { Gear, Trash } from "react-bootstrap-icons";

const href = "#";
const size = 16;

const listActions = (props) => {
  const { showEdit, showEditHandler, showDelete, showDeleteHandler } = props;

  const editIcon = showEdit ? (
    <a href={href} onClick={showEditHandler}>
      <Gear size={size} />
    </a>
  ) : null;

  const trashIcon = showDelete ? (
    <a href={href} onClick={showDeleteHandler}>
      <Trash size={size} />
    </a>
  ) : null;

  return (
    <span className={props.className}>
      {editIcon}
      {trashIcon}
    </span>
  );
};
export default listActions;
