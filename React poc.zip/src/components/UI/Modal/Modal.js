import React from "react";
import Modal from "react-bootstrap/Modal";
import Alert from "react-bootstrap/Alert";
import Button from "../Button/Button";
import { getButtonConfig } from "../Button/util";
import classes from "./Modal.module.css";

const modal = (props) => {
  const {
    title,
    submitHandler,
    cancelHandler,
    submitBtnLabel,
    cancelBtnLabel,
    showSubmit,
    showCancel,
    disableSubmit,
    disableCancel,
    errors,
  } = props.modalConfig;

  const submitBtnConfig = getButtonConfig(
    submitHandler,
    submitBtnLabel,
    showSubmit,
    disableSubmit,
    "P"
  );
  const submitBtn = <Button buttonConfig={submitBtnConfig} />;

  const cancelBtnConfig = getButtonConfig(
    cancelHandler,
    cancelBtnLabel,
    showCancel,
    disableCancel,
    "S"
  );
  const cancelBtn = <Button buttonConfig={cancelBtnConfig} />;

  const errorSection = errors ? <Alert variant="danger">{errors}</Alert> : null;

  let modal = (
    <Modal
      show={true}
      centered={true}
      className={classes.modal}
      backdrop="static"
      onHide={cancelHandler}
    >
      <Modal.Header closeButton>
        <Modal.Title>{title}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {errorSection}
        {props.children}
      </Modal.Body>
      <Modal.Footer>
        {cancelBtn}
        {submitBtn}
      </Modal.Footer>
    </Modal>
  );

  return modal;
};

export default modal;
