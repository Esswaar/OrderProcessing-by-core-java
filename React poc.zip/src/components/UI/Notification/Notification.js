import React from "react";
import Toast from "react-bootstrap/Toast";
import { useDispatch } from "react-redux";
import actionTypes from "../../../store/actionTypes/actionTypes";
import classes from "./Notification.module.css";
import { CheckCircleFill } from "react-bootstrap-icons";

const Notification = (props) => {
  const dispatch = useDispatch();
  const hide = () => {
    dispatch({ type: actionTypes.RESET_SUCCESS });
  };

  return (
    <div className={classes.wrapper}>
      <Toast
        className={classes.notification}
        onClose={hide}
        delay={3000}
        autohide
      >
        <Toast.Header className={classes.header}>
          <CheckCircleFill className={classes.success} />
          <span>Saved successfully</span>
        </Toast.Header>
      </Toast>
    </div>
  );
};

export default Notification;
