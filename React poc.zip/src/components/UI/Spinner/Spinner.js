import React from "react";
import Spinner from "react-bootstrap/Spinner";
import classes from "./Spinner.module.css";

const spinner = (props) => {
  return (
    <Spinner animation="border" variant="primary" className={classes.spinner} />
  );
};

export default spinner;
