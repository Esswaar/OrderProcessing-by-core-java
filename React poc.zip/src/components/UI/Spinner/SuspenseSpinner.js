import React from "react";
import Spinner from "./Spinner";
import classes from "./Spinner.module.css";

const spinner = (props) => {
  const classArr = [classes.suspenseSpinnerWrapper];
  if (props.isInLayout) {
    classArr.push(classes.suspenseSpinnerWrapperInLayout);
  }
  return (
    <div className={classArr.join(" ")}>
      <Spinner />
    </div>
  );
};

export default spinner;
