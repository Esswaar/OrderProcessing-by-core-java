import Input from "../UI/Forms/Input";
import React from "react";
import stepTypes from "../../services/mockData/step.types";
import operators from "../../services/mockData/route.operators";

export const createUIElemFromConfig = (form, setFormConfig) => {
  const formConfig = form.config;
  const formElementsArray = [];
  for (let key in formConfig) {
    formElementsArray.push({
      id: key,
      config: formConfig[key],
    });
  }
  const checkValidity = (value, rules) => {
    let isValid = true;
    if (!rules) {
      return true;
    }

    if (rules.required) {
      isValid = value.trim() !== "" && isValid;
    }

    return isValid;
  };

  const inputChangedHandler = (event, id) => {
    const clone = require("rfdc")();
    const updatedForm = clone(form);
    const config = updatedForm.config;
    const updatedFormElement = {
      ...config[id],
    };
    updatedFormElement.value = event.target.value;
    updatedFormElement.valid = checkValidity(
      updatedFormElement.value,
      updatedFormElement.validation
    );
    updatedFormElement.touched = true;
    config[id] = updatedFormElement;

    let isFormValid = true;
    for (let id in config) {
      isFormValid =
        (config[id].valid ||
          checkValidity(config[id].value, config[id].validation)) &&
        isFormValid;
      if (!isFormValid) {
        break;
      }
    }
    setFormConfig({ config: config, isValid: isFormValid });
  };

  const formData = formElementsArray.map((formElement) => (
    <Input
      key={formElement.id}
      name={formElement.id}
      elementType={formElement.config.elementType}
      elementConfig={formElement.config.elementConfig}
      value={formElement.config.value}
      placeholder={formElement.config.elementConfig.placeholder}
      invalid={!formElement.config.valid}
      shouldValidate={formElement.config.validation}
      touched={formElement.config.touched}
      changed={(event) => inputChangedHandler(event, formElement.id)}
    />
  ));
  return formData;
};

export const prepareExistingEntities = (entities) => {
  const resultEntities = [];
  if (entities) {
    Object.values(entities).forEach((entity) => {
      if (entity._status !== "new") {
        resultEntities.push({ id: entity.id, displayValue: entity.name });
      }
    });
  }
  return resultEntities;
};

export const updateFormWithExistingEntities = (form, type, entities) => {
  const clone = require("rfdc")();
  const updatedForm = clone(form);
  const updatedFormConfig = updatedForm.config;
  const options = updatedFormConfig[type].elementConfig.options;
  updatedFormConfig[type].elementConfig.options = options.concat(entities);
  return updatedForm;
};

export const getStepTypes = () => {
  const stepTypesList = [];
  Object.values(stepTypes).forEach((stepType) => {
    stepTypesList.push({ id: stepType.value, displayValue: stepType.label });
  });
  return stepTypesList;
};

export const getOperators = () => {
  const operatorList = [];
  Object.values(operators).forEach((operator) => {
    operatorList.push({ id: operator.value, displayValue: operator.label });
  });
  return operatorList;
};

export const getLabel = (type, operation) => {
  const prefix = getLabelPrefix(operation);
  switch (type) {
    case "stage":
      return `${prefix}stage`;
    case "process":
      return `${prefix}process`;
    case "step":
      return `${prefix}step`;
    default:
      return null;
  }
};

const getLabelPrefix = (operation) => {
  switch (operation) {
    case "edit":
      return "Edit ";
    case "delete":
      return "Delete ";
    default:
      return "Add ";
  }
};

export const getEntityDetails = (props, entityForm, newForm, existingForm) => {
  let entityDetails = null;
  if (isNewForm(entityForm)) {
    entityDetails = getNewFormEntityDetails(props, newForm);
  } else {
    entityDetails = {
      _status: "existing",
      id: existingForm.config[props.type].value,
    };
  }
  entityDetails["config"] = props;
  return entityDetails;
};

export const updateEntityDetails = (type, id, entityEditForm) => {
  let entityDetails = {};
  setEntityDetails(entityDetails, entityEditForm);
  entityDetails["_config"] = {};
  entityDetails._config.type = type;
  entityDetails._config.id = id;
  return entityDetails;
};

export const getNewFormEntityDetails = (props, newForm) => {
  let entityDetails = null;
  entityDetails = {
    _status: "new",
    id: Date.now(),
  };
  setEntityDetails(entityDetails, newForm);
  entityDetails["config"] = props;
  return entityDetails;
};

const setEntityDetails = (entityDetails, entityForm) => {
  const formConfig = entityForm.config;
  for (let id in formConfig) {
    const elem = formConfig[id];
    entityDetails[elem.elementConfig.context] = elem.value;
  }
};

export const isNewForm = (entityForm) => {
  return entityForm.config.createOption.value === "new";
};

export const preparePayloadFromForm = (form) => {
  const payload = {};
  const formConfig = form.config;
  for (let id in formConfig) {
    const elem = formConfig[id];
    payload[elem.elementConfig.context] = elem.value;
  }
  return payload;
};

export const prepareEditForm = (form, entity) => {
  const clone = require("rfdc")();
  const updatedForm = clone(form);
  const updatedFormConfig = updatedForm.config;
  for (let key in updatedFormConfig) {
    const value = entity[key];
    updatedFormConfig[key].value = value ? value : "";
  }
  return updatedForm;
};
