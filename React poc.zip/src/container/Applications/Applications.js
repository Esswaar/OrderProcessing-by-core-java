import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import CreateApplication from "../../components/Applications/CreateApplication/CreateApplication";
import ApplicationCard from "../../components/Applications/ApplicationCard/ApplicationCard";
import classes from "./Applications.module.css";
import Breadcrumb from "../../components/UI/Breadcrumb/Breadcrumb";
import {
  createApp,
  loadApps,
  cancelCreateApp,
} from "../../store/actions/application.action";

const Applications = (props) => {
  const applications = useSelector((state) => state.app.applications);
  const isCreatingApp = useSelector((state) => state.app.isCreatingApp);
  const errors = useSelector((state) => state.app.errors);
  const dispatch = useDispatch();

  const dispatchLoadApps = () => {
    dispatch(loadApps());
  };

  useEffect(dispatchLoadApps, []);

  const appCards = applications.map((app) => (
    <ApplicationCard key={app.id} app={app} />
  ));

  const dispatchCreateApp = (appDetails) => {
    dispatch(createApp(appDetails));
  };

  const dispatchCancelCreateApp = () => {
    dispatch(cancelCreateApp());
  };

  const addAppCard = (
    <CreateApplication
      createHandler={dispatchCreateApp}
      cancelHandler={dispatchCancelCreateApp}
      isCreatingApp={isCreatingApp}
      errors={errors}
    />
  );

  return (
    <React.Fragment>
      <Breadcrumb />
      <div className={classes.appGrid}>
        {appCards}
        {addAppCard}
      </div>
    </React.Fragment>
  );
};

export default Applications;
