import React, { useEffect, useState } from "react";
import createAuthFormConfig from "./AuthFormConfig";
import { useDispatch, useSelector } from "react-redux";
import Forms from "../../components/UI/Forms/Forms";
import brandLogo from "../../assets/pypegasyslogo.png";
import {
  doAuthenticate,
  authenticateFromLS,
} from "../../store/actions/auth.action";
import { createUIElemFromConfig } from "../../components/Util/Util";
import Styles from "./Auth.module.css";

const Auth = () => {
  const authInfo = getAuthInfoFromLS();
  const verifyAuthInfo = () => {
    if (hasTokenInfoLS(authInfo)) {
      dispatch(authenticateFromLS(authInfo));
    }
  };
  useEffect(verifyAuthInfo, []);

  const [createAuthForm, setCreateAuthForm] = useState(createAuthFormConfig);

  const dispatch = useDispatch();
  const dispatchAuthentication = () => {
    const form = createAuthForm.config;
    dispatch(doAuthenticate(form.userName.value, form.password.value));
  };
  const errors = useSelector((state) => state.auth.errorMsg);

  const formConfig = {
    showSubmit: true,
    showCancel: false,
    submitBtnLabel: "Login",
    submitHandler: dispatchAuthentication,
    errors: errors,
  };

  const authForm = hasTokenInfoLS(authInfo) ? null : (
    <div className={Styles.Login}>
      <img src={brandLogo} alt="Pegasystems" />
      <Forms formConfig={formConfig}>
        {createUIElemFromConfig(createAuthForm, setCreateAuthForm)}
      </Forms>
    </div>
  );

  return authForm;
};

const getAuthInfoFromLS = () => {
  const authInfo = localStorage.authInfo;
  try {
    return JSON.parse(authInfo);
  } catch {
    return null;
  }
};

const hasTokenInfoLS = (authInfo) => {
  return authInfo && authInfo.token;
};

export default Auth;
