const createAuthForm = () => {
  return {
    config: {
      userName: {
        elementType: "input",
        elementConfig: {
          type: "text",
          placeholder: "User name",
          context: "userName",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
      password: {
        elementType: "password",
        elementConfig: {
          type: "password",
          placeholder: "Password",
          context: "password",
        },
        value: "",
        validation: {
          required: true,
        },
        valid: false,
        touched: false,
      },
    },
    isValid: false,
  };
};

export default createAuthForm;
