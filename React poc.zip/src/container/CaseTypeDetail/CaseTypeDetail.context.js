import React from "react";

const CaseTypeContext = React.createContext({});

export default CaseTypeContext;