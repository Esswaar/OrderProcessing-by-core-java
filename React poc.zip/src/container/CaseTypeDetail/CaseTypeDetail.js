import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import StageCV from "../../components/CaseTypeDetail/CardView/Stage";
import Stage from "../../components/CaseTypeDetail/ListView/Stage";
import CaseTypeContext from "./CaseTypeDetail.context";
import NewStage from "../../components/CaseTypeDetail/AddEntity/Stage/NewStage";
import classes from "./CaseTypeDetail.module.css";
import cardViewClasses from "../../components/CaseTypeDetail/CardView/CardView.module.css";
import Breadcrumb from "../../components/UI/Breadcrumb/Breadcrumb";
import { Button } from "react-bootstrap";
import { LayoutThreeColumns, List } from "react-bootstrap-icons";
import {
  loadCaseTypeDetail,
  loadCaseTypeDetailOnly,
  saveCaseTypeDetail,
} from "../../store/actions/casetypeDetail.action";

const CaseTypeDetail = (props) => {
  const { appID, caseTypeID } = props.match.params;

  const casetypeDetail = useSelector(
    (state) => state.casetypeDetail.caseDetails
  );
  const casetypeState = useSelector((state) => state.casetype);
  const applications = useSelector((state) => state.app.applications);
  const appInfo = casetypeState.appInfo;

  const dispatch = useDispatch();
  const dispatchLoadCasetypeDetail = () => {
    if (appInfo.id) {
      dispatch(loadCaseTypeDetailOnly(appID, caseTypeID));
    } else {
      dispatch(loadCaseTypeDetail(appID, applications, caseTypeID));
    }
  };
  useEffect(dispatchLoadCasetypeDetail, []);

  const dispatchSaveCasetypeDetail = () => {
    dispatch(saveCaseTypeDetail(appID, caseTypeID, casetypeDetail));
  };

  const [isListView, setIsListView] = useState(false);
  const actionBar = getActionBar(
    setIsListView,
    isListView,
    dispatchSaveCasetypeDetail
  );
  const caseTypeView = getCaseTypeView(casetypeDetail, isListView);

  return (
    <div className={classes.caseTypeDetail}>
      <Breadcrumb appInfo={appInfo} caseTypeInfo={casetypeDetail} />
      <CaseTypeContext.Provider value={casetypeDetail}>
        {actionBar}
        {caseTypeView}
      </CaseTypeContext.Provider>
    </div>
  );
};

const getStages = (casetypeDetail, isListView) => {
  if (casetypeDetail.stages) {
    return casetypeDetail.stages.map((stage, index) => {
      if (stage._status === "deleted") {
        return null;
      }
      const id = stage.id;
      const detail = casetypeDetail["_stages"][id];
      const config = {
        key: `${id}_${index}`,
        stageDetails: detail,
      };
      return isListView ? <Stage {...config} /> : <StageCV {...config} />;
    });
  }
};

const getCaseTypeView = (casetypeDetail, isListView) => {
  const stages = getStages(casetypeDetail, isListView);
  return isListView ? (
    <ol className={classes.stagesList}>
      {stages}
      <NewStage />
    </ol>
  ) : (
    <div className={cardViewClasses.stages}>
      {stages}
      <span className={classes.addStage}>
        <NewStage viewType="card" />
      </span>
    </div>
  );
};

const getActionBar = (viewActionHandler, isListView, saveHandler) => (
  <div className={classes.actionBar}>
    {getViewTypeButtons(viewActionHandler, isListView)}
    <div className={classes.caseTypeActions}>
      <Button variant="primary" onClick={saveHandler}>
        Save
      </Button>
    </div>
  </div>
);

const getViewTypeButtons = (viewActionHandler, isListView) => {
  return (
    <div className={classes.viewTypeActions}>
      <Button
        variant="light"
        disabled={isListView}
        onClick={() => viewActionHandler(true)}
      >
        <List />
      </Button>
      <Button
        variant="light"
        disabled={!isListView}
        onClick={() => viewActionHandler(false)}
      >
        <LayoutThreeColumns />
      </Button>
    </div>
  );
};

export default CaseTypeDetail;
