import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import CaseTypeCard from "../../components/CaseTypes/CaseTypeCard/CaseTypeCard";
import CreateCaseType from "../../components/CaseTypes/CreateCaseType/CreateCaseType";
import classes from "../Applications/Applications.module.css";
import Breadcrumb from "../../components/UI/Breadcrumb/Breadcrumb";
import {
  loadCaseDatails,
  createCase,
  cancelCreateCase,
} from "../../store/actions/casetype.action";

const CaseTypes = (props) => {
  const { appID } = props.match.params;

  const applications = useSelector((state) => state.app.applications);
  const casetypeState = useSelector((state) => state.casetype);
  const casetypes = casetypeState.casetypes;
  const appInfo = casetypeState.appInfo;
  const isCreatingCaseType = casetypeState.isCreatingCaseType;
  const errors = casetypeState.errors;

  const dispatch = useDispatch();
  const dispatchLoadCaseTypes = () => {
    dispatch(loadCaseDatails(appID, applications));
  };

  useEffect(dispatchLoadCaseTypes, []);

  const caseTypeCards = casetypes.map((caseObj) => (
    <CaseTypeCard key={caseObj.id} caseType={caseObj} appInfo={appInfo} />
  ));

  const dispatchCreateCaseType = (caseDetails) => {
    dispatch(createCase(caseDetails,appInfo));
  };

  const dispatchCancelCreateCaseType = () => {
    dispatch(cancelCreateCase());
  };

  const addCaseTypeCard = (
    <CreateCaseType
      createHandler={dispatchCreateCaseType}
      cancelHandler={dispatchCancelCreateCaseType}
      isCreatingCaseType={isCreatingCaseType}
      errors={errors}
    />
  );

  return (
    <React.Fragment>
      <Breadcrumb appInfo={appInfo} />
      <h4 className={classes.myApp}>Case types</h4>
      <div className={classes.appGrid}>
        {caseTypeCards}
        {addCaseTypeCard}
      </div>
    </React.Fragment>
  );
};

export default CaseTypes;
