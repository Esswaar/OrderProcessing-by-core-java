import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import classes from "./Layout.module.css";
import { useSelector } from "react-redux";
import SuspenseSpinner from "../../components/UI/Spinner/SuspenseSpinner";
import Notification from "../../components/UI/Notification/Notification";
import Sidebar from "../../components/Sidebar/Sidebar";

const Layout = (props) => {
  const { isLoading, success } = useSelector((state) => state.ui);
  const loader = isLoading ? <SuspenseSpinner isInLayout={true} /> : null;
  const notification = success ? <Notification /> : null;
  const layoutJsx = (
    <Container className={classes.container} fluid>
      <Row className={classes.body}>
        <Col className={classes.sidebar}>
          <Sidebar />
        </Col>
        <Col className={classes.mainArea}>{props.children}</Col>
      </Row>
    </Container>
  );

  return (
    <React.Fragment>
      {notification}
      {loader}
      {layoutJsx}
    </React.Fragment>
  );
};

export default Layout;
