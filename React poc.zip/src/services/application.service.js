import authoringServices from "./util/authoringServices";
import endpoints from "./util/endpoints";
import * as serviceUtils from "./util/serviceUtils";
import * as properties from "./util/properties";

export const loadApplications = () => {
  if (properties.isServerIntegrated) {
    return authoringServices
      .get(endpoints.APPLICATIONS)
      .then((response) => {
        return response;
      })
      .catch((err) => {
        return serviceUtils.getErrorPromise(err);
      });
  } else {
    return mockAppLoadApp();
  }
};

const mockAppLoadApp = async () => {
  return [];
};

const mockAppCreation = async (payload) => {
  return payload;
};

export const createApplication = (payload) => {
  if (properties.isServerIntegrated) {
    return authoringServices
      .post(endpoints.APPLICATIONS, payload)
      .then((response) => {
        return response;
      })
      .catch((err) => {
        return serviceUtils.getErrorPromise(err);
      });
  } else {
    return mockAppCreation(payload);
  }
};

const mockGetApp = async () => {
  return { id: new Date().getMilliseconds(), name: "Test app" };
};

export const getApplication = (id) => {
  /*if (properties.isServerIntegrated) {
    return authoringServices
      .get(endpoints.APPLICATIONS + "/" + id)
      .then((response) => {
        return response;
      })
      .catch((err) => {
        return serviceUtils.getErrorPromise(err);
      });
  } else {*/
  return mockGetApp();
  //}
};
