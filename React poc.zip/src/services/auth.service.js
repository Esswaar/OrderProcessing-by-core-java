import usersList from "./mockData/auth.users";

const authenticate = (userName, password) => {
  if (userName in usersList) {
    if (usersList[userName].password === password) {
      return mockAuth(userName, password);
    } else {
      return new Promise((resolve, reject) => {
        reject("Invalid Password");
      });
    }
  } else {
    return new Promise((resolve, reject) => {
      reject("Invalid User name");
    });
  }
};

const mockAuth = async (userName, password) => {
  return { token: new Date().getTime(), id: userName, info: { name: "Abc" } };
};

export default authenticate;
