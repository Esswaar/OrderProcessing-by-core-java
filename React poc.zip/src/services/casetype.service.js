import authoringServices from "./util/authoringServices";
import endpoints from "./util/endpoints";
import * as serviceUtils from "./util/serviceUtils";
import * as properties from "./util/properties";

export const loadCaseTypes = (id) => {
  if (properties.isServerIntegrated) {
    return authoringServices
      .get(endpoints.APPLICATIONS+"/"+id+"/"+endpoints.CASETYPES)
      .then((response) => {
        return response.data;
      })
      .catch((err) => {
        return serviceUtils.getErrorPromise(err);
      });
  } else {
    return mockCasTypeData();
  }
};

const mockCasTypeData = async () => {
  return [
    {
      name: "Hire",
      description: "Case type manage the hiring process",
      id: 1,
    },
    {
      name: "Interview",
      description: "This case type is used for conducting the interviews.",
      id: 2,
    },
  ];
};

export const createCaseType = (payload, appInfo) => {
  if (properties.isServerIntegrated) {
    return authoringServices
      .post(
        endpoints.APPLICATIONS + "/" + appInfo.id + "/" + endpoints.CASETYPES,
        payload
      )
      .then((response) => {
        return response;
      })
      .catch((err) => {
        return serviceUtils.getErrorPromise(err);
      });
  } else {
    return mockCaseTypeCreation(payload);
  }
};

const mockCaseTypeCreation = async (payload) => {
  return { data: payload };
};
