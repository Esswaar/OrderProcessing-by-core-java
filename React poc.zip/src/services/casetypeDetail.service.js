import authoringServices from "./util/authoringServices";
import endpoints from "./util/endpoints";
import * as serviceUtils from "./util/serviceUtils";
import * as properties from "./util/properties";
import mockData from "./mockData/caseType.detail";
import { cloneState } from "../store/util/util";

export const loadCaseDetails = (appId, caseId) => {
  if (properties.isServerIntegrated) {
    return authoringServices
      .get(
        endpoints.APPLICATIONS +
          "/" +
          appId +
          "/" +
          endpoints.CASETYPES +
          "/" +
          caseId
      )
      .then((response) => {
        flattenNode(response.data, response.data, getNodeByLevel(1), 1);
        updateResponse(response.data);
        //console.log(response);
        return response;
      })
      .catch((err) => {
        return serviceUtils.getErrorPromise(err);
      });
  } else {
    return mockCaseTypeDetails();
  }
};

const mockCaseTypeDetails = async () => {
  const clone = require("rfdc")();
  const data = clone(mockData.data);
  flattenNode(data, data, getNodeByLevel(1), 1);
  return { data: data };
};

const flattenNode = (root, curRoot, node, level) => {
  if (node == null) {
    return;
  }
  delete curRoot["_action"];
  const _node = `_${node}`;
  const nodes = curRoot[node];

  if (!root[_node]) {
    root[_node] = {};
  }

  const nodeArr = [];

  if (nodes) {
    nodes.forEach((cur) => {
      nodeArr.push({ id: cur.id });
      root[_node][cur.id] = cur;
      flattenNode(root, cur, getNodeByLevel(level + 1), level + 1);
    });
  }

  curRoot[node] = nodeArr;
};

const updateResponse = (data) => {
  const entities = ["_stages", "_processes", "_steps"];
  entities.forEach((entity) => {
    if (!data[entity]) {
      data[entity] = {};
    }
  });
};

const getNodeByLevel = (level) => {
  switch (level) {
    case 1:
      return "stages";
    case 2:
      return "processes";
    case 3:
      return "steps";
    default:
      return null;
  }
};

export const saveCaseDetails = (appId, caseId, caseTypeDetail) => {
  if (properties.isServerIntegrated) {
    const reqBody = prepareSaveRequestBody(cloneState(caseTypeDetail));
    return authoringServices
      .put(
        endpoints.APPLICATIONS +
          "/" +
          appId +
          "/" +
          endpoints.CASETYPES +
          "/" +
          caseId,
        reqBody
      )
      .then((response) => {
        flattenNode(response.data, response.data, getNodeByLevel(1), 1);
        updateResponse(response.data);
        //console.log(response);
        return response;
      })
      .catch((err) => {
        return serviceUtils.getErrorPromise(err);
      });
  } else {
    return prepareSaveRequestBody(cloneState(caseTypeDetail));
  }
};

const prepareSaveRequestBody = (caseTypeDetail) => {
  prepareEntities(
    caseTypeDetail.stages,
    caseTypeDetail._stages,
    caseTypeDetail,
    2
  );
  setAction(caseTypeDetail);
  delete caseTypeDetail["_status"];
  delete caseTypeDetail["_stages"];
  delete caseTypeDetail["_processes"];
  delete caseTypeDetail["_steps"];
  return caseTypeDetail;
};

const prepareEntities = (targetList, sourceList, caseTypeDetail, level) => {
  if (!targetList) {
    return;
  }
  for (let i = targetList.length - 1; i >= 0; i--) {
    let target = targetList[i];
    const id = target.id;
    let status = target._status;
    const action = target._action;
    if (status === "deleted") {
      targetList.splice(i, 1);
    } else {
      target = targetList[i] = sourceList[id];
      if (action === "A") {
        delete target["id"];
      }
      setAction(target);
      delete target["_status"];

      if (level < 4) {
        const nextNode = getNodeByLevel(level);
        prepareEntities(
          target[nextNode],
          caseTypeDetail[`_${nextNode}`],
          caseTypeDetail,
          level + 1
        );
      }
    }
  }
};

const setAction = (target) => {
  const status = target._status;
  if (status) {
    target["_action"] = status;
  }
};
