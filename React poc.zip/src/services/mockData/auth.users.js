const usersList = {
    tharun:{
        password:"rules"
    },
    rajesh:{
        password:"rules"
    },
    shibram:{
        password:"rules"
    },
}
export default usersList;