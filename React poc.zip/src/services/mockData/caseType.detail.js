const data = {
  data: {
    id: "1",
    name: "Job Applicant",
    description: "Job Applicant",
    stages: [
      {
        id: "1",
        name: "Collect resume",
        description: "Collect resume",
        processes: [
          {
            id: "1",
            name: "Candidate application",
            description: "Candidate application",
            steps: [
              {
                id: "1",
                type: "FlowAction",
                name: "Personal Information",
                description: "Personal Information",
              },
              {
                id: "2",
                type: "FlowAction",
                name: "Professional Information",
                description: "Professional Information",
              },
            ],
          },
          {
            id: "2",
            name: "Upload documents",
            description: "Upload documents",
            steps: [
              {
                id: "3",
                type: "FlowAction",
                name: "Upload Salary slip",
                description: "Upload Salary slip",
              },
            ],
          },
        ],
      },
      {
        id: "2",
        name: "Recruiter Review",
        description: "Recruiter Review",
      },
    ],
  },
};

export default data;
