const operators = [
  {
    label: "Shibram",
    value: "Shibram",
  },
  {
    label: "Rajesh",
    value: "Rajesh",
  },
  {
    label: "Tharun",
    value: "Tharun",
  },
];
export default operators;
