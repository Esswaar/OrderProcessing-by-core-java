const stepTypes = [
  {
    label: "Assignment",
    value: "Flow Action",
  },
];
export default stepTypes;
