import axios from "axios";

const authService = axios.create({
  baseURL: "http://localhost:8080/",
});

export default authService;
