const endpoints = {
  LOGIN: "login",
  APPLICATIONS: "applications",
  CASETYPES: "casetypes",
};

export default endpoints;
