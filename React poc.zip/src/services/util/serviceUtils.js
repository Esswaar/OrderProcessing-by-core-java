export const getErrorPromise = (err) => {
  return Promise.reject(err);
};
