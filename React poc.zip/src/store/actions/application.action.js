import actionTypes from "../actionTypes/actionTypes";
import {
  setIsLoading,
  resetIsLoading,
  setSuccess,
  resetSuccess,
} from "../util/util";
import {
  loadApplications,
  createApplication,
} from "../../services/application.service";

const loadAppsStart = () => {
  return {
    type: actionTypes.APPS_LOAD_START,
  };
};

const loadAppsDone = (response) => {
  return {
    type: actionTypes.APPS_LOAD_DONE,
    payload: response.data.applications,
  };
};

const loadAppsFail = (error) => {
  return {
    type: actionTypes.APPS_LOAD_FAIL,
    payload: {},
  };
};

export const appCreateInit = () => {
  return {
    type: actionTypes.APP_CREATE_INIT,
    payload: "",
  };
};

export const loadApps = () => {
  return (dispatch) => {
    setIsLoading(dispatch, actionTypes);
    dispatch(loadAppsStart());
    loadApplications()
      .then((resp) => {
        resetIsLoading(dispatch, actionTypes);
        dispatch(loadAppsDone(resp));
      })
      .catch((err) => {
        resetIsLoading(dispatch, actionTypes);
        dispatch(loadAppsFail(err));
      });
  };
};

const createAppStart = () => {
  return {
    type: actionTypes.APP_CREATE_START,
  };
};

const createAppDone = (response) => {
  return {
    type: actionTypes.APP_CREATE_DONE,
    payload: response.data,
  };
};

const createAppFail = (error) => {
  return {
    type: actionTypes.APP_CREATE_FAIL,
    payload: {},
  };
};

export const createApp = (payload) => {
  return (dispatch) => {
    setIsLoading(dispatch, actionTypes);
    resetSuccess(dispatch, actionTypes);
    dispatch(createAppStart());
    createApplication(payload)
      .then((resp) => {
        resp.data.name = payload.name;
        resp.data.description = payload.description;
        resetIsLoading(dispatch, actionTypes);
        dispatch(createAppDone(resp));
        setSuccess(dispatch, actionTypes);
      })
      .catch((err) => {
        resetIsLoading(dispatch, actionTypes);
        dispatch(createAppFail(err));
      });
  };
};

const createAppCancel = () => {
  return {
    type: actionTypes.APP_CREATE_CANCEL,
  };
};

export const cancelCreateApp = () => {
  return (dispatch) => {
    dispatch(createAppCancel());
  };
};
