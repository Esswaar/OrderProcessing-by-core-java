import actionTypes from "../actionTypes/actionTypes";
import authenticate from "../../services/auth.service";

const authStart = () => {
  return {
    type: actionTypes.AUTH_START,
  };
};

const authSuccess = (response) => {
  return {
    type: actionTypes.AUTH_SUCCESS,
    payload: response,
  };
};

const authFail = (error) => {
  return {
    type: actionTypes.AUTH_FAIL,
    payload: {
      isAuthenticated: false,
      errorMsg: error,
    },
  };
};

export const doAuthenticate = (userName, password) => {
  return (dispatch) => {
    dispatch(authStart());
    authenticate(userName, password)
      .then((resp) => {
        dispatch(authSuccess(resp));
      })
      .catch((err) => {
        dispatch(authFail(err));
      });
  };
};

const authRoute = (route) => {
  return {
    type: actionTypes.SET_AUTH_ROUTE,
    payload: { route: route },
  };
};

export const setAuthRoute = (route) => {
  return (dispatch) => {
    dispatch(authRoute(route));
  };
};

export const clearAuthRoute = () => {
  return (dispatch) => {
    dispatch({
      type: actionTypes.CLEAR_AUTH_ROUTE,
    });
  };
};

export const authenticateFromLS = (authInfo) => {
  return (dispatch) => {
    dispatch({ type: actionTypes.AUTH_FROM_LS, payload: authInfo });
  };
};

export const logout = () => {
  return (dispatch) => {
    dispatch({ type: actionTypes.LOG_OUT });
  };
};
