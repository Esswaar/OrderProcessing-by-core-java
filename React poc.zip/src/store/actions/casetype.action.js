import actionTypes from "../actionTypes/actionTypes";
import { loadCaseTypes, createCaseType } from "../../services/casetype.service";
import { getApplication } from "../../services/application.service";
import {
  setIsLoading,
  resetIsLoading,
  setSuccess,
  resetSuccess,
} from "../util/util";

const loadCaseTypesStart = () => {
  return {
    type: actionTypes.CASETYPES_LOAD_START,
  };
};

const loadCaseTypesDone = (response) => {
  return {
    type: actionTypes.CASETYPES_LOAD_DONE,
    payload: response,
  };
};

const loadCaseTypesFail = (error) => {
  return {
    type: actionTypes.CASETYPES_LOAD_FAIL,
    payload: {},
  };
};

export const caseCreateInit = () => {
  return {
    type: actionTypes.CASE_CREATE_INIT,
    payload: "",
  };
};

const createCaseStart = () => {
  return {
    type: actionTypes.CASETYPE_CREATE_START,
  };
};

const createCaseDone = (response) => {
  return {
    type: actionTypes.CASETYPE_CREATE_DONE,
    payload: response.data,
  };
};

const createCaseFail = (error) => {
  return {
    type: actionTypes.CASETYPE_CREATE_FAIL,
    payload: {},
  };
};

const createCaseTypeCancel = () => {
  return {
    type: actionTypes.CASE_CREATE_CANCEL,
  };
};

export const cancelCreateCase = () => {
  return (dispatch) => {
    dispatch(createCaseTypeCancel());
  };
};

export const createCase = (payload, appInfo) => {
  return (dispatch) => {
    setIsLoading(dispatch, actionTypes);
    resetSuccess(dispatch, actionTypes);
    dispatch(createCaseStart());
    createCaseType(payload, appInfo)
      .then((resp) => {
        resp.data.name = payload.name;
        resp.data.description = payload.description;
        // resp.data.id = new Date().getTime().toString();
        resetIsLoading(dispatch, actionTypes);
        dispatch(createCaseDone(resp));
        setSuccess(dispatch, actionTypes);
      })
      .catch((err) => {
        resetIsLoading(dispatch, actionTypes);
        dispatch(createCaseFail(err));
      });
  };
};

const getAppDone = (app) => {
  return {
    type: actionTypes.APP_GET_DONE,
    payload: {
      appInfo: app,
    },
  };
};

export const loadCaseDatails = (id, applications) => {
  return async (dispatch) => {
    setIsLoading(dispatch, actionTypes);
    dispatch(loadCaseTypesStart());
    let found = false;
    const app = applications.find((app) => app.id === id);
    if (!app) {
      try {
        const result = await getApplication(id);
        dispatch(getAppDone(result));
        found = true;
      } catch (err) {
        resetIsLoading(dispatch, actionTypes);
        dispatch(loadCaseTypesFail(err));
      }
    } else {
      const result = { name: app.name, id: id };
      dispatch(getAppDone(result));
      found = true;
    }

    if (found) {
      loadCaseTypes(id)
        .then((resp) => {
          resetIsLoading(dispatch, actionTypes);
          dispatch(loadCaseTypesDone(resp));
        })
        .catch((err) => {
          resetIsLoading(dispatch, actionTypes);
          dispatch(loadCaseTypesFail(err));
        });
    } else {
      resetIsLoading(dispatch, actionTypes);
      dispatch(loadCaseTypesFail("Application not found"));
    }
  };
};
