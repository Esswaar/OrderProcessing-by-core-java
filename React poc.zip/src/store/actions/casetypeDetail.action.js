import actionTypes from "../actionTypes/actionTypes";
import {
  loadCaseDetails,
  saveCaseDetails,
} from "../../services/casetypeDetail.service";
import { getApplication } from "../../services/application.service";
import {
  setIsLoading,
  resetIsLoading,
  setSuccess,
  resetSuccess,
} from "../util/util";

const loadCaseDetailsStart = () => {
  return {
    type: actionTypes.CASE_DETAILS_LOAD_START,
  };
};

const loadCaseDetailsDone = (response) => {
  return {
    type: actionTypes.CASE_DETAILS_LOAD_DONE,
    payload: response.data,
  };
};

const loadCaseDetailsFail = (error) => {
  return {
    type: actionTypes.CASE_DETAILS_LOAD_FAIL,
    payload: {},
  };
};

const getAppDone = (app) => {
  return {
    type: actionTypes.APP_GET_DONE,
    payload: {
      appInfo: app,
    },
  };
};

export const loadCaseTypeDetail = (appID, applications, caseID) => {
  return async (dispatch) => {
    setIsLoading(dispatch, actionTypes);
    dispatch(loadCaseDetailsStart());
    let found = false;
    const app = applications
      ? applications.find((app) => app.id === appID)
      : false;
    if (!app) {
      try {
        const result = await getApplication(appID);
        dispatch(getAppDone(result));
        found = true;
      } catch (err) {
        resetIsLoading(dispatch, actionTypes);
        dispatch(loadCaseDetailsFail(err));
      }
    } else {
      const result = { name: app.name, id: appID };
      dispatch(getAppDone(result));
      found = true;
    }

    if (found) {
      loadCaseTypeDetailInner(dispatch, appID, caseID);
    } else {
      resetIsLoading(dispatch, actionTypes);
      dispatch(loadCaseDetailsFail("Application not found"));
    }
  };
};

export const loadCaseTypeDetailOnly = (appID, caseID) => {
  return (dispatch) => {
    loadCaseTypeDetailInner(dispatch, appID, caseID);
  };
};

const loadCaseTypeDetailInner = (dispatch, appID, caseID) => {
  loadCaseDetails(appID, caseID)
    .then((resp) => {
      resetIsLoading(dispatch, actionTypes);
      dispatch(loadCaseDetailsDone(resp));
    })
    .catch((err) => {
      resetIsLoading(dispatch, actionTypes);
      dispatch(loadCaseDetailsFail(err));
    });
};

export const addEntity = (entityDetails) => {
  return {
    type: actionTypes.CREATE_ENTITY_START,
    payload: entityDetails,
  };
};

export const editEntity = (entityDetails) => {
  return {
    type: actionTypes.EDIT_ENTITY_START,
    payload: entityDetails,
  };
};

export const deleteEntity = (entityDetails) => {
  return {
    type: actionTypes.DELETE_ENTITY_START,
    payload: entityDetails,
  };
};

const saveCaseDetailsStart = () => {
  return {
    type: actionTypes.CASE_DETAILS_SAVE_START,
  };
};

const saveCaseDetailsDone = (response) => {
  return {
    type: actionTypes.CASE_DETAILS_SAVE_DONE,
    payload: response.data,
  };
};

const saveCaseDetailsFail = (response) => {
  return {
    type: actionTypes.CASE_DETAILS_SAVE_FAIL,
    payload: response,
  };
};

export const saveCaseTypeDetail = (appID, caseID, caseTypeDetail) => {
  return (dispatch) => {
    setIsLoading(dispatch, actionTypes);
    resetSuccess(dispatch, actionTypes);
    dispatch(saveCaseDetailsStart);
    saveCaseDetails(appID, caseID, caseTypeDetail)
      .then((resp) => {
        resetIsLoading(dispatch, actionTypes);
        dispatch(saveCaseDetailsDone(resp));
        setSuccess(dispatch, actionTypes);
      })
      .catch((err) => {
        resetIsLoading(dispatch, actionTypes);
        dispatch(saveCaseDetailsFail(err));
      });
  };
};
