import actionTypes from "../actionTypes/actionTypes";
import { cloneState } from "../util/util";

const initialState = {
  applications: [
    // {
    //   name: null,
    //   version: null,
    //   id: null,
    //   description: null,
    // },
  ],
  errors: null,
  isCreatingApp: false,
};

const appCreationDone = (state, action) => {
  const updatedAppState = cloneState(state);
  updatedAppState.applications.push(action.payload);
  updatedAppState.isCreatingApp = false;
  return updatedAppState;
};

const appInitDone = (state) => {
  const updatedAppState = cloneState(state);
  updatedAppState.isCreatingApp = true;
  return updatedAppState;
};

const appLoadDone = (state, action) => {
  const updatedAppState = cloneState(state);
  updatedAppState.applications = action.payload;
  return updatedAppState;
};

const appReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.APPS_LOAD_START:
      return { ...state };
    case actionTypes.APPS_LOAD_DONE:
      return appLoadDone(state, action);
    case actionTypes.APPS_LOAD_FAIL:
      return { ...state };
    case actionTypes.APP_CREATE_START:
      return { ...state };
    case actionTypes.APP_CREATE_DONE:
      return appCreationDone(state, action);
    case actionTypes.APP_CREATE_FAIL:
      return { ...state };
    case actionTypes.APP_CREATE_INIT:
      return appInitDone(state);
    case actionTypes.APP_CREATE_CANCEL:
      return { ...state, isCreatingApp: false };
    default:
      return { ...state };
  }
};

export default appReducer;
