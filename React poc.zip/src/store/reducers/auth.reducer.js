import actionTypes from "../actionTypes/actionTypes";

const initialState = {
  id: null,
  token: null,
  info: null,
  route: null,
};

const DEFAULT_ROUTE = "/";

const setSuccessResponse = (state, action) => {
  let route = state.route;
  if (route && route === "/auth") {
    route = DEFAULT_ROUTE;
  }
  const updatedState = {
    ...state,
    ...action.payload,
    route: route,
  };
  localStorage.authInfo = JSON.stringify(action.payload);
  return updatedState;
};

const logout = () => {
  localStorage.removeItem("authInfo");
  return initialState;
};

const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.AUTH_START:
      return { ...state };
    case actionTypes.AUTH_SUCCESS:
      return setSuccessResponse(state, action);
    case actionTypes.AUTH_FAIL:
      return { ...state, ...action.payload };
    case actionTypes.SET_AUTH_ROUTE:
      return { ...state, route: action.payload.route };
    case actionTypes.CLEAR_AUTH_ROUTE:
      return { ...state, route: DEFAULT_ROUTE };
    case actionTypes.AUTH_FROM_LS:
      return { ...action.payload, route: state.route };
    case actionTypes.LOG_OUT:
      return logout();
    default:
      return { ...state };
  }
};

export default authReducer;
