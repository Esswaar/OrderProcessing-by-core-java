import actionTypes from "../actionTypes/actionTypes";
import { cloneState } from "../util/util";

const initialState = {
  casetypes: [
    // {
    //   name: null,
    //   id: null,
    //   description: null,
    // },
  ],
  appInfo: {
    id: null,
    name: null,
  },
  errors: null,
  isCreatingCaseType: false,
};

const caseLoadDone = (state, action) => {
  const updatedCaseState = cloneState(state);
  updatedCaseState.casetypes = action.payload;
  return updatedCaseState;
};

const caseInitDone = (state) => {
  const updatedCaseState = cloneState(state);
  updatedCaseState.isCreatingCaseType = true;
  return updatedCaseState;
};

const caseCreationDone = (state, action) => {
  const updatedCaseState = cloneState(state);
  updatedCaseState.casetypes.push(action.payload);
  updatedCaseState.isCreatingCaseType = false;
  return updatedCaseState;
};

const getAppDone = (state, action) => {
  const updatedCaseState = cloneState(state);
  updatedCaseState.appInfo = action.payload.appInfo;
  return updatedCaseState;
};

const caseTypeReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.CASETYPES_LOAD_START:
      return { ...state };
    case actionTypes.CASETYPES_LOAD_DONE:
      return caseLoadDone(state, action);
    case actionTypes.CASETYPES_LOAD_FAIL:
      return { ...state };
    case actionTypes.CASE_CREATE_INIT:
      return caseInitDone(state);
    case actionTypes.CASETYPE_CREATE_START:
      return { ...state };
    case actionTypes.CASE_CREATE_CANCEL:
      return { ...state, isCreatingCaseType: false };
    case actionTypes.CASETYPE_CREATE_DONE:
      return caseCreationDone(state, action);
    case actionTypes.APP_GET_DONE:
      return getAppDone(state, action);
    default:
      return { ...state };
  }
};

export default caseTypeReducer;
