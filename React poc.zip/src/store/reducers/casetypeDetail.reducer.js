import actionTypes from "../actionTypes/actionTypes";
import { cloneState } from "../util/util";

const initialState = {
  caseDetails: {},
};

const getCaseDetailsDone = (state, action) => {
  //const updatedCaseDetails = cloneState(state);
  //updatedCaseDetails.caseDetails = action.payload;
  return { caseDetails: action.payload };
  //return updatedCaseDetails;
};

const saveCaseDetailsDone = (state, action) => {
  //const updatedCaseDetails = cloneState(state);
  //updatedCaseDetails.caseDetails = action.payload;
  return { caseDetails: action.payload };
  //return state;
};

const processCreateEntity = (type, parent, targetList, entityDetails) => {
  if (parent[type] === undefined) {
    parent[type] = [];
  }
  const id = entityDetails.id;
  const refList = parent[type];
  if (entityDetails._status === "new") {
    refList.push({ id: id, _action: "A" });
    targetList[id] = entityDetails;
  } else {
    refList.push({ id: id, _action: "AE" });
    /*const index = getEntityIndex(refList, id);
    if (index > -1) {
      const ref = refList[index];
      delete ref["_status"];
      delete ref["_action"];
      refList.splice(index, 1);
      refList.push(ref);
    } else {
      refList.push({ id: id, _action: "AE" });
    }*/
  }
  if (parent._status !== "new") {
    parent._status = "updated";
  }
  delete entityDetails["config"];
};

const createStage = (state, entityDetails) => {
  const caseDetail = state.caseDetails;
  processCreateEntity(
    "stages",
    caseDetail,
    state.caseDetails._stages,
    entityDetails
  );
};

const createProcess = (state, entityDetails) => {
  const stage = state.caseDetails._stages[entityDetails.config.stageID];
  processCreateEntity(
    "processes",
    stage,
    state.caseDetails._processes,
    entityDetails
  );
};

const createStep = (state, entityDetails) => {
  const process = state.caseDetails._processes[entityDetails.config.processID];
  processCreateEntity(
    "steps",
    process,
    state.caseDetails._steps,
    entityDetails
  );
};

const createEntity = (state, entityDetails) => {
  const updatedCaseState = cloneState(state);
  switch (entityDetails.config.type) {
    case "stage":
      createStage(updatedCaseState, entityDetails);
      break;
    case "process":
      createProcess(updatedCaseState, entityDetails);
      break;
    case "step":
      createStep(updatedCaseState, entityDetails);
      break;
    default:
      return updatedCaseState;
  }
  return updatedCaseState;
};

const processUpdateEntity = (targetList, entityDetails) => {
  const id = entityDetails._config.id;
  delete entityDetails["_config"];
  targetList[id] = { ...targetList[id], ...entityDetails };
  if (targetList[id]._status !== "new") {
    targetList[id]._status = "updated";
  }
};

const updateStep = (state, entityDetails) => {
  processUpdateEntity(state.caseDetails._steps, entityDetails);
};

const updateProcess = (state, entityDetails) => {
  processUpdateEntity(state.caseDetails._processes, entityDetails);
};

const updateStage = (state, entityDetails) => {
  processUpdateEntity(state.caseDetails._stages, entityDetails);
};

const updateEntity = (state, entityDetails) => {
  const updatedCaseState = cloneState(state);
  switch (entityDetails._config.type) {
    case "stage":
      updateStage(updatedCaseState, entityDetails);
      break;
    case "process":
      updateProcess(updatedCaseState, entityDetails);
      break;
    case "step":
      updateStep(updatedCaseState, entityDetails);
      break;
    default:
      return updatedCaseState;
  }
  return updatedCaseState;
};

const getEntityIndex = (refList, id) => {
  for (let i = 0; i < refList.length; i++) {
    if (refList[i].id === id) {
      return i;
    }
  }
  return -1;
};

const processDeleteEntity = (refList, targetList, entityDetails) => {
  const id = entityDetails._config.id;
  const index = getEntityIndex(refList, id);
  if (index > -1) {
    refList.splice(index, 1);
  }
  if (targetList[id]._status === "new") {
    delete targetList[id];
  }
};

const deleteStep = (state, entityDetails) => {
  const parent = state.caseDetails._processes[entityDetails._config.parentId];
  processDeleteEntity(parent.steps, state.caseDetails._steps, entityDetails);
  parent._status = "updated";
};

const deleteProcess = (state, entityDetails) => {
  const parent = state.caseDetails._stages[entityDetails._config.parentId];
  processDeleteEntity(
    parent.processes,
    state.caseDetails._processes,
    entityDetails
  );
  parent._status = "updated";
};

const deleteStage = (state, entityDetails) => {
  processDeleteEntity(
    state.caseDetails.stages,
    state.caseDetails._stages,
    entityDetails
  );
  state.caseDetails._status = "updated";
};

const deleteEntity = (state, entityDetails) => {
  const updatedCaseState = cloneState(state);
  switch (entityDetails._config.type) {
    case "stage":
      deleteStage(updatedCaseState, entityDetails);
      break;
    case "process":
      deleteProcess(updatedCaseState, entityDetails);
      break;
    case "step":
      deleteStep(updatedCaseState, entityDetails);
      break;
    default:
      return updatedCaseState;
  }
  return updatedCaseState;
};

const caseDetailsReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.CASE_DETAILS_LOAD_START:
      return { ...state };
    case actionTypes.CASE_DETAILS_LOAD_DONE:
      return getCaseDetailsDone(state, action);
    case actionTypes.CASE_DETAILS_LOAD_FAIL:
      return { ...state };
    case actionTypes.CREATE_ENTITY_START:
      return createEntity(state, action.payload);
    case actionTypes.EDIT_ENTITY_START:
      return updateEntity(state, action.payload);
    case actionTypes.DELETE_ENTITY_START:
      return deleteEntity(state, action.payload);
    case actionTypes.CASE_DETAILS_SAVE_DONE:
      return saveCaseDetailsDone(state, action);
    case actionTypes.CASE_DETAILS_SAVE_FAIL:
      return { ...state };
    default:
      return { ...state };
  }
};

export default caseDetailsReducer;
