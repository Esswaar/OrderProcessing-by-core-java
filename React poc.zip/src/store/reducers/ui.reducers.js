import actionTypes from "../actionTypes/actionTypes";

const initialState = {
  isLoading: false,
  success: false,
};

const uiReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.SET_IS_LOADING:
      return { ...state, isLoading: true };
    case actionTypes.RESET_IS_LOADING:
      return { ...state, isLoading: false };
    case actionTypes.SET_SUCCESS:
      return { ...state, success: true };
    case actionTypes.RESET_SUCCESS:
      return { ...state, success: false };
    default:
      return { ...state };
  }
};

export default uiReducer;
