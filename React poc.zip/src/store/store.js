import { createStore, combineReducers, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";
import appReducer from "./reducers/application.reducer";
import authReducer from "./reducers/auth.reducer";
import caseTypeReducer from "./reducers/casetype.reducer";
import uiReducer from "./reducers/ui.reducers";
import caseTypeDetail from "./reducers/casetypeDetail.reducer";

const rootReducer = combineReducers({
  auth: authReducer,
  app: appReducer,
  casetype: caseTypeReducer,
  ui: uiReducer,
  casetypeDetail: caseTypeDetail,
});

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const store = createStore(
  rootReducer,
  composeEnhancers(applyMiddleware(thunk))
);

export default store;
