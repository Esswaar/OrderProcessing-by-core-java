const clone = require("rfdc")();
export const cloneState = (state) => clone(state);

export const setIsLoading = (dispatch, actionTypes) => {
  dispatch({ type: actionTypes.SET_IS_LOADING });
};

export const resetIsLoading = (dispatch, actionTypes) => {
  dispatch({ type: actionTypes.RESET_IS_LOADING });
};

export const setSuccess = (dispatch, actionTypes) => {
  dispatch({ type: actionTypes.SET_SUCCESS });
};

export const resetSuccess = (dispatch, actionTypes) => {
  dispatch({ type: actionTypes.RESET_SUCCESS });
};
