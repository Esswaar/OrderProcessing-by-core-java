import './App.css';
import Sidebar from './components/Sidebar';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Header from './components/header'
import AdhocRun from './components/adhoc-run';
import Dashboard from './components/validation-dashboard';

function App() {
  return (
    <Router>
      <Sidebar />
   <Switch>
     <Route exact path="/adhoc" component={AdhocRun} />
     <Route exact path="/dashboard" component={Dashboard} />
   </Switch>
    </Router>
  );
}

export default App;
