import React from 'react';

import * as RiIcons from 'react-icons/ri';

const validationRules = [
  {
      id : 1,
      title : "Validation_Rule_1",
      path : "/dashboard"
  },
  {
      id : 2,
      title : "Validation_Rule_2",
      path : "/dashboard"
  },
  {
      id : 3,
      title : "Validation_Rule_3"
  },
  {
      id : 4,
      title : "Validation_Rule_4"
  },
  {
      id : 5,
     title : "Validation_Rule_5"
  }
]

export const ProductsData = [
  {
    title: 'Prouct 1',
    id: 1,
    validationRules: validationRules,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />
  },
  {
    title: 'Prouct 2',
    id: 2,
    validationRules: validationRules,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />
  },
  {
    title: 'Prouct 3',
    id: 3,
    validationRules: validationRules,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />
  }

];
