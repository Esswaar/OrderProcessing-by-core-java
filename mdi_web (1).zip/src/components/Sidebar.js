import React, { useState } from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import { ProductsData } from './ProductsData';
import ValidationRule from './ValidationRule';
import { IconContext } from 'react-icons/lib';
import Dashboard from './validation-dashboard';
import {Container,Row,Col} from 'react-bootstrap';

const Nav = styled.div`
  background: #15171c;
  height: 80px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;

const NavIcon = styled(Link)`
  margin-left: 2rem;
  font-size: 2rem;
  height: 80px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;

const SidebarNav = styled.nav`
  background: #15171c;
  width: 250px;
  height: 100vh;
  display: flex;
  justify-content: center;
  position: fixed;
  top: 0;
  left: ${({ sidebar }) => (sidebar ? '0' : '-100%')};
  transition: 350ms;
  z-index: 10;
`;

const SidebarWrap = styled.div`
  width: 100%;
`;

const Sidebar = () => {
  const [sidebar, setSidebar] = useState(false);
  const [loadDashboard, setLoadDashboard] = React.useState(false);
  const showSidebar = () => setSidebar(!sidebar);
  let dashboard;

  const showDashBoard = () =>{
    setLoadDashboard(true);
}

  if(loadDashboard){
      dashboard =  <Col sm={8}><Dashboard/></Col> 
  }else{
      dashboard = <Col sm={8}></Col>
  }
  return (
    <Container>
    <Row>
      <Col sm={4}>
      <IconContext.Provider value={{ color: '#fff' }}>
        <Nav>
          <NavIcon to='#'>
            <FaIcons.FaBars onClick={showSidebar} />
          </NavIcon>
          <NavIcon to='#'>
            <Link onClick={showSidebar} >Validation-Rules</Link>
          </NavIcon>
          <NavIcon to='/adhoc'>
            <Link to='/adhoc'>Ad-Hoc Run</Link>
          </NavIcon>
          <NavIcon to='/dashboard'>
            <Link to='/dashboard'>Validation Dashboard</Link>
          </NavIcon>

        </Nav>
        
        <SidebarNav sidebar={sidebar}>
          <SidebarWrap>
            <NavIcon to='#'>
              <AiIcons.AiOutlineClose onClick={showSidebar} />
            </NavIcon>
            {ProductsData.map((item, index) => {
              return <ValidationRule item={item} key={index} />;
            })}
          </SidebarWrap>
        </SidebarNav>
      </IconContext.Provider>
      </Col>
    
    {dashboard}
   </Row>
 </Container>
  );
};

export default Sidebar;
