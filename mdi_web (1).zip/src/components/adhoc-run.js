import React from 'react'

const adhoc = () => {
    return (
        <h1>Adhoc</h1>
    )
}

export default adhoc