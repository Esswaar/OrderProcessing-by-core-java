import React from 'react'

const data = {
    "rule name" : "Rule Name",
    "rule description" : "Rule description"
}

const dashboard = () => {
    return (
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      ><pre>{JSON.stringify(data, null, 2) }</pre></div>
    )
}

export default dashboard