import React from 'react'

const adhoc = () => {
    return (
    <br/>
    )
}

export default adhoc