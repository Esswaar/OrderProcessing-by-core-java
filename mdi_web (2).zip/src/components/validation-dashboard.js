import React, { useState } from 'react';
import JSONInput from 'react-json-editor-ajrm';
import locale    from 'react-json-editor-ajrm/locale/en';
import darktheme from 'react-json-editor-ajrm/themes';
import {Container,Row,Col,Button} from 'react-bootstrap';

const data = {
    "rule name" : "Rule Name",
    "rule description" : "Rule description"
}

const Dashboard = () => {
    const [readOnly, setReadOnly] = useState(true);
    const [json,setJson] = useState(data);
    const deActivate = () =>{
        let obj = {};
        setJson(obj);
        setReadOnly(false);
    }

    const edit = () =>{
        setReadOnly(false);
    }

    const newRule = () =>{
        let obj = {
            "rule name" : "",
            "rule description" : ""
        }
        setJson(obj);
        setReadOnly(false);
    }
    return (
        <div className="rule">
            <Container>
                <Row >
             <Button className="ruleActions" variant="secondary" size="lg" onClick={deActivate}>
     De-Activate
    </Button>
   
             <Button  className="ruleActions" variant="secondary" size="lg" onClick={edit}>
     Edit
    </Button>
    
             <Button  className="ruleActions" variant="secondary" size="lg" onClick={newRule}>
     New
    </Button>
    
    </Row>
    <br/>
    <Row>
            <JSONInput
        id          = 'a_unique_id'
        placeholder = { json }
        colors      = { darktheme }
        locale      = { locale }
        viewOnly = {readOnly}
        height      = '450px'
    />
    </Row>
    </Container>
    </div>
    )
}

export default Dashboard