import React from 'react';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import { BrowserRouter as Router, Switch, Route,withRouter } from "react-router-dom";
import Header from './components/header'
import Validation from './components/validation-rules';
import AdhocRun from './components/adhoc-run';
import Dashboard from './components/validation-dashboard';

const App = () => {
  return (
    <Router>
   <Header/>
   <Switch>
     <Route exact path="/" component={Validation} />
     <Route exact path="/adhoc" component={AdhocRun} />
     <Route exact path="/dashboard" component={Dashboard} />
   </Switch>
 </Router>
  );
}

export default withRouter(App);
