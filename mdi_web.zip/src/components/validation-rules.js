import React from 'react'
import {NavDropdown, Nav,Container,Row,Col} from 'react-bootstrap'
import {LinkContainer} from 'react-router-bootstrap'
import Dashboard from './validation-dashboard';


export default function Validation (){

    const [loadDashboard, setLoadDashboard] = React.useState(false);

    // data will be replaced by service
const productlist = [
    {
        "id" : 1,
        "name": "Prouct 1"
    },
    {
        "id" : 2,
        "name": "Prouct 2"
    },
    {
        "id" : 3,
        "name": "Prouct 3"
    }
];

const validationRules = [
    {
        "id" : 1,
        "name" : "Validation_Rule_1"
    },
    {
        "id" : 2,
        "name" : "Validation_Rule_2"
    },
    {
        "id" : 3,
        "name" : "Validation_Rule_3"
    },
    {
        "id" : 4,
        "name" : "Validation_Rule_4"
    },
    {
        "id" : 5,
        "name" : "Validation_Rule_5"
    }
]

const showDashBoard = () =>{
    setLoadDashboard(true);
}

const validationRulesMenu = validationRules.map((validationRule) => (
    <Nav bg="light" variant="light">
  <Nav.Link href="#" onClick={showDashBoard}>{validationRule.name}</Nav.Link>
 
</Nav>
));



const productMenu = productlist.map((product) => (
    <NavDropdown title={product.name} id="collasible-nav-dropdown" key = {product.id}>
        
    {validationRulesMenu}
    </NavDropdown>
  ));

  let dashboard
  if(loadDashboard){
      dashboard =  <Col sm={8}><Dashboard/></Col> 
  }else{
      dashboard = <Col sm={8}></Col>
  }
    return (
        <Container>
        <Row>
          <Col sm={4}>{productMenu}</Col>
        
         {dashboard}
        </Row>
      </Container>
         
   
    )


    }